#!/bin/sh
/opt/ArchGenXML/ArchGenXML.py DummyPloneProduct.zargo -o ..
rm -rf /home/gde/ZopeInstance/Products/DummyPloneProduct
cp -r ../../DummyPloneProduct /home/gde/ZopeInstance/Products

