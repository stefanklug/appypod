# -*- coding: utf-8 -*-
#
# File: Test1.py
#
# Copyright (c) 2007 by []
# Generator: ArchGenXML Version 1.5.3 dev/svn
#            http://plone.org/products/archgenxml
#
# GNU General Public License (GPL)
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
# 02110-1301, USA.
#

__author__ = """unknown <unknown>"""
__docformat__ = 'plaintext'

from AccessControl import ClassSecurityInfo
from Products.Archetypes.atapi import *
from Products.DummyPloneProduct.config import *

##code-section module-header #fill in your manual code here
import time, os, os.path
import appy.pod.renderer
import Products.DummyPloneProduct
##/code-section module-header

schema = Schema((

    TextField(
        name='at1',
        allowable_content_types=('text/plain', 'text/structured', 'text/html', 'application/msword',),
        widget=RichWidget(
            label='At1',
            label_msgid='DummyPloneProduct_label_at1',
            i18n_domain='DummyPloneProduct',
        ),
        default_output_type='text/html'
    ),

),
)

##code-section after-local-schema #fill in your manual code here
##/code-section after-local-schema

Test1_schema = BaseSchema.copy() + \
    schema.copy()

##code-section after-schema #fill in your manual code here
##/code-section after-schema

class Test1(BaseContent):
    """
    """
    security = ClassSecurityInfo()
    __implements__ = (getattr(BaseContent,'__implements__',()),)

    # This name appears in the 'add' box
    archetype_name = 'Test1'

    meta_type = 'Test1'
    portal_type = 'Test1'
    allowed_content_types = []
    filter_content_types = 0
    global_allow = 1
    #content_icon = 'Test1.gif'
    immediate_view = 'base_view'
    default_view = 'base_view'
    suppl_views = ()
    typeDescription = "Test1"
    typeDescMsgId = 'description_edit_test1'


    actions =  (


       {'action': "string:$object_url/generateOdt",
        'category': "document_actions",
        'id': 'asOdt',
        'name': 'Generer en ODT',
        'permissions': ("View",),
        'condition': 'python:1'
       },


    )

    _at_rename_after_creation = True

    schema = Test1_schema

    ##code-section class-header #fill in your manual code here
    ##/code-section class-header

    # Methods

    # Manually created methods

    security.declarePublic('generateOdt')
    def generateOdt(self, RESPONSE):
        '''Generates the ODT version of this advice.'''
        return self._generate(RESPONSE, 'odt')

    def _generate(self, response, fileType):
        '''Generates a document that represents this advice.
        The document format is specified by p_fileType.'''
        # First, generate the PDF in a temp file
        tempFileName = '/tmp/%s.%f.%s' % (self._at_uid, time.time(),
                                          fileType)
        renderer = appy.pod.renderer.Renderer(
           '%s/Xhtml.odt' % os.path.dirname(Products.DummyPloneProduct.__file__),
           {'dummy': self}, tempFileName)
        renderer.run()
        # Tell the browser that the resulting page contains PDF
        response.setHeader('Content-type', 'application/%s' % fileType)
        response.setHeader('Content-disposition',
                           'inline;filename="%s.%s"' % (self.id, fileType))
        # Returns the doc and removes the temp file
        f = open(tempFileName, 'rb')
        doc = f.read()
        f.close()
        os.remove(tempFileName)
        return doc



registerType(Test1, PROJECTNAME)
# end of class Test1

##code-section module-footer #fill in your manual code here
##/code-section module-footer



