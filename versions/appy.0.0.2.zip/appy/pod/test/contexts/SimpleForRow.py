from appy.pod.test.contexts import Person

persons = [Person('Mr 1'), Person('Ms One'), Person('Misss two')]
