# ------------------------------------------------------------------------------
# Appy is a framework for building applications in the Python language.
# Copyright (C) 2007 Gaetan Delannay

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301,USA.

# ------------------------------------------------------------------------------
import time
from appy.shared.utils import Traceback

# Some POD-specific constants --------------------------------------------------
XHTML_HEADINGS = ('h1', 'h2', 'h3', 'h4', 'h5', 'h6')
XHTML_LISTS = ('ol', 'ul')
XHTML_PARAGRAPH_TAGS = XHTML_HEADINGS + XHTML_LISTS + ('p',)
XHTML_PARAGRAPH_TAGS_NO_LISTS = XHTML_HEADINGS + ('p',)
XHTML_INNER_TAGS = ('b', 'i', 'u', 'em')
XHTML_UNSTYLABLE_TAGS = XHTML_LISTS + ('li', 'a')
XML_SPECIAL_CHARS = {'<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;',
                     "'": '&apos;'}

# OpenDocument namespaces ------------------------------------------------------
DC_NAMESPACE = 'http://purl.org/dc/elements/1.1/'
OFFICE_NAMESPACE = 'urn:oasis:names:tc:opendocument:xmlns:office:1.0'
STYLE_NAMESPACE = 'urn:oasis:names:tc:opendocument:xmlns:style:1.0'
TEXT_NAMESPACE = 'urn:oasis:names:tc:opendocument:xmlns:text:1.0'

# ------------------------------------------------------------------------------
class PodError(Exception):
    def dumpTraceback(buffer, tb):
        i = 0
        for tLine in tb.splitlines():
            i += 1
            if i > 3:
                buffer.write('<text:p>')
                buffer.dumpContent(tLine)
                buffer.write('</text:p>')
    dumpTraceback = staticmethod(dumpTraceback)
    def dump(buffer, message, withinElement=None):
        '''Dumps the error p_message in p_buffer.'''
        if withinElement:
            buffer.write('<%s>' % withinElement.OD)
            for subTag in withinElement.subTags:
                buffer.write('<%s>' % subTag)
        buffer.write('<office:annotation><dc:creator>POD</dc:creator>' \
                     '<dc:date>%s</dc:date><text:p>' % \
                     time.strftime('%Y-%m-%dT%H:%M:%S'))
        buffer.dumpContent(message)
        buffer.write('</text:p>')
        PodError.dumpTraceback(buffer, Traceback.get())
        buffer.write('</office:annotation>')
        if withinElement:
            subTags = withinElement.subTags[:]
            subTags.reverse()
            for subTag in subTags:
                buffer.write('</%s>' % subTag)
            buffer.write('</%s>' % withinElement.OD)
    dump = staticmethod(dump)
# ------------------------------------------------------------------------------
