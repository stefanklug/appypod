# ------------------------------------------------------------------------------
# Appy is a framework for building applications in the Python language.
# Copyright (C) 2007 Gaetan Delannay

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301,USA.

# ------------------------------------------------------------------------------
import xml.sax
from xml.sax.handler import ContentHandler
from appy.pod import *

# To which ODT tag does HTML tags correspond ?
HTML_2_ODT = {'h1':'h', 'h2':'h', 'h3':'h', 'h4':'h', 'h5':'h', 'h6':'h',
              'p':'p', 'b':'span', 'i':'span', 'strong':'span', 'em': 'span',
              'sub': 'span', 'sup': 'span', 'br': 'line-break'}
DEFAULT_ODT_STYLES = {'b': 'podBold', 'strong':'podBold', 'i': 'podItalic',
                      'em': 'podItalic', 'sup': 'podSup', 'sub':'podSub'}

# ------------------------------------------------------------------------------
class XhtmlEnvironment:
    def __init__(self, converter):
        self.res = u''
        self.currentContent = u''
        self.currentElements = [] # Stack of currently walked elements
        self.currentLists = [] # Stack of currently walked lists (ul or ol)
        self.creatingRootParagraph = False
        # Within the XHTML chunk given to this parser, there may be some
        # content that is not enclosed within any tag (at "root" level). When I
        # encounter such content, I will include it into a root paragraph with
        # default style. This content may include sub-tags of course (span,
        # div, img, a...) or may already be dumped entirely if I encounter
        # "paragraph-style" sub-tags (h1, h2, p...). self.creatingRootParagraph
        # tells me if I am still in a root paragraph. So when I encounter a
        # "root" content I know if I must reopen a new paragraph or not, for
        # example.
        self.styles = converter.odtStyles
        self.converter = converter
        self.textNs = 'text' # This value should come from namespaces parsing
        self.linkNs = 'xlink' # Idem
        # from content.xml
    def getCurrentElement(self, isList=False):
        '''Gets the element that is on the top of self.currentElements or
           self.currentLists.'''
        res = None
        if isList:
            elements = self.currentLists # Stack of list elements only
        else:
            elements = self.currentElements # Stack of all elements
        if elements:
            res = elements[len(elements)-1]
        return res
    def dumpRootParagraph(self, currentElem=None):
        '''Dumps content that is outside any tag (directly within the root
           "podXhtml" tag.'''
        mustStartParagraph = True
        mustEndParagraph = True
        if self.creatingRootParagraph:
            mustStartParagraph = False
        elif not self.currentContent:
            return
        if currentElem and not (currentElem in XHTML_PARAGRAPH_TAGS):
            mustEndParagraph = False
        if mustStartParagraph:
            self.dumpStyledElement('p', {})
            self.creatingRootParagraph = True
        self.dumpCurrentContent()
        if mustEndParagraph:
            self.res += '</%s:p>' % self.textNs
            self.creatingRootParagraph = False
    def dumpCurrentContent(self):
        '''Dumps content that was temporarily stored in self.currentContent
           into the final buffer self.res.'''
        for c in self.currentContent:
            if XML_SPECIAL_CHARS.has_key(c):
                self.res += XML_SPECIAL_CHARS[c]
            else:
                self.res += c
        self.currentContent = u''
    def dumpStyledElement(self, elem, attrs):
        '''Dumps an element that potentially has associated style
           information.'''
        self.res += '<%s:%s' % (self.textNs, HTML_2_ODT[elem])
        odtStyle = self.converter.findStyle(elem, attrs)
        styleName = None
        if odtStyle:
            styleName = odtStyle.name
        elif DEFAULT_ODT_STYLES.has_key(elem):
            styleName = DEFAULT_ODT_STYLES[elem]
        if styleName:
            self.res += ' %s:style-name="%s"' % (self.textNs, styleName)
            if (elem in XHTML_HEADINGS) and (odtStyle.outlineLevel != None):
                self.res += ' %s:outline-level="%d"' % (
                    self.textNs, odtStyle.outlineLevel)
        self.res += '>'
    def onElementStart(self, elem, attrs):
        self.currentContent = self.currentContent.strip('\n')
        if (self.getCurrentElement() == 'podXhtml'):
            self.dumpRootParagraph(elem)
        else:
            self.dumpCurrentContent()
        self.currentElements.append(elem)
        # Update stack of current lists
        if elem in XHTML_LISTS:
            self.currentLists.append(elem)
    def onElementEnd(self, elem):
        self.currentElements.pop()
        if elem in XHTML_LISTS:
            self.currentLists.pop()
        self.currentContent = self.currentContent.strip('\n')
        if elem == 'podXhtml':
            self.dumpRootParagraph()
        else:
            self.dumpCurrentContent()

# ------------------------------------------------------------------------------
class XhtmlHandler(ContentHandler):
    listStyles = {'ul': 'podBulletedList', 'ol': 'podNumberedList'}
    itemStyles = {'ul': 'podBulletItem', 'ol': 'podNumberItem'}
    def __init__(self, converter):
        ContentHandler.__init__(self)
        self.converter = converter
        self.env = XhtmlEnvironment(converter)
    def setDocumentLocator(self, locator):
        self.locator = locator
    def endDocument(self):
        self.converter.odtChunk = OdtChunk(self.env.res)
    def startElement(self, elem, attrs):
        e = self.env
        e.onElementStart(elem, attrs)
        if HTML_2_ODT.has_key(elem):
            e.dumpStyledElement(elem, attrs)
        elif elem == 'a':
            e.res += '<%s:a %s:type="simple"' % (e.textNs, e.linkNs)
            if attrs.has_key('href'):
                e.res += ' %s:href="%s"' % (e.linkNs, attrs['href'])
            e.res += '>'
        elif elem in XHTML_LISTS:
            prologue = ''
            if len(e.currentLists) >= 2:
                # It is a list into another list. In this case the inner list
                # must be surrounded by a list-item element.
                prologue = '<%s:list-item>' % e.textNs
            e.res += '%s<%s:list %s:style-name="%s">' % (
                prologue, e.textNs, e.textNs, self.listStyles[elem])
        elif elem == 'li':
            e.res += '<%s:list-item><%s:p %s:style-name="%s">' % (
                e.textNs, e.textNs, e.textNs,
                self.itemStyles[e.getCurrentElement(isList=True)])
    def endElement(self, elem):
        e = self.env
        e.onElementEnd(elem)
        if HTML_2_ODT.has_key(elem):
            e.res += '</%s:%s>' % (e.textNs, HTML_2_ODT[elem])
        elif elem == 'a':
            e.res += '</%s:a>' % e.textNs
        elif elem in XHTML_LISTS:
            epilogue = ''
            if len(e.currentLists) >= 1:
                # We were in an inner list. So we must close the list-item tag
                # that surrounds it.
                epilogue = '</%s:list-item>' % e.textNs
            e.res += '</%s:list>%s' % (e.textNs, epilogue)
        elif elem == 'li':
            e.res += '</%s:p></%s:list-item>' % (e.textNs, e.textNs)
    def characters(self, content):
        self.env.currentContent += content

# -------------------------------------------------------------------------------
class OdtChunk:
    '''Represents a chunk of ODT XML file, that must be inserted into a
       content.xml.'''
    def __init__(self, content):
        self.content = content

# -------------------------------------------------------------------------------
class Xhtml2OdtConverter:
    '''Converts a chunk of XHTML into a chunk of ODT.'''
    def __init__(self, xhtmlString, encoding, stylesManager, localStylesMapping):
        self.xhtmlString = xhtmlString
        self.encoding = encoding # Todo: manage encoding that is not utf-8
        self.stylesManager = stylesManager
        self.odtStyles = stylesManager.styles
        self.globalStylesMapping = stylesManager.stylesMapping
        self.localStylesMapping = localStylesMapping
        self.odtChunk = None
        self.xhtmlHandler = XhtmlHandler(self)
    def run(self):
        xml.sax.parseString(self.xhtmlString, self.xhtmlHandler)
        #print 'ODT chunk is **', self.odtChunk.content, '**'
        #print
        return self.odtChunk
    def findStyle(self, elem, attrs):
        '''Finds the ODT style that must be applied to XHTML p_elem that has
           attrs p_attrs. Here is the places where we will search, ordered by
           priority (highest first):
           (1) local styles mapping (CSS style in "class" attr)
           (2)         "            (HTML elem)
           (3) global styles mapping (CSS style in "class" attr)
           (4)          "            (HTML elem)
           (5) ODT style that has the same name as CSS style in "class" attr
           (6) ODT style that has the same outline level as HTML elem.'''
        res = None
        cssStyleName = None
        if attrs.has_key('class'):
            cssStyleName = attrs['class']
        # (1)
        if self.localStylesMapping.has_key(cssStyleName):
            res = self.localStylesMapping[cssStyleName]
        # (2)
        elif self.localStylesMapping.has_key(elem):
            res = self.localStylesMapping[elem]
        # (3)
        elif self.globalStylesMapping.has_key(cssStyleName):
            res = self.globalStylesMapping[cssStyleName]
        # (4)
        elif self.globalStylesMapping.has_key(elem):
            res = self.globalStylesMapping[elem]
        # (5)
        elif self.odtStyles.has_key(cssStyleName):
            res = self.odtStyles[cssStyleName]
        # (6)
        else:
            # Try to find a style with the correct outline level
            if elem in XHTML_HEADINGS:
                # Is there a delta that must be taken into account ?
                outlineDelta = 0
                if self.localStylesMapping.has_key('h*'):
                    outlineDelta += self.localStylesMapping['h*']
                elif self.globalStylesMapping.has_key('h*'):
                    outlineDelta += self.globalStylesMapping['h*']
                outlineLevel = int(elem[1]) + outlineDelta
                # Normalize the outline level
                if outlineLevel < 1: outlineLevel = 1
                res = self.odtStyles.getParagraphStyleAtLevel(outlineLevel)
        if res:
            self.stylesManager.checkStylesAdequation(elem, res)
        return res
# ------------------------------------------------------------------------------
