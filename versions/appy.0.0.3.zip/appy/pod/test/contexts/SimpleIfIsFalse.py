c1 = False
