Directory 'skins/DummyPloneProduct':

Put your templates, css and javascript files in here. When first
installed, this skin layer is added to the plone skin. It is added
right below the 'custom' layer. Later, other products can move it a
little bit down, but it'll always be above the plone skin layers. So:
you can use it to overwrite plone stuff.

