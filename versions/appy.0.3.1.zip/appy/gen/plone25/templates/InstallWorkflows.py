# -*- coding: utf-8 -*-
#
# GNU General Public License (GPL)
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
# 02110-1301, USA.
#

from Products.CMFCore.utils import getToolByName
from Products.ExternalMethod.ExternalMethod import ExternalMethod
from Products.<!applicationName!>.config import PROJECTNAME
workflows = {<!workflows!>}

def installWorkflows(self, package, out):
    """Install the custom workflows for this product."""

    workflowTool = getToolByName(self, 'portal_workflow')
    for contentType, workflowName in workflows.iteritems():
        # Register the workflow if needed
        if workflowName not in workflowTool.listWorkflows():
            wfMethod = ExternalMethod(
            'temp', 'temp', PROJECTNAME + '.' + workflowName,
            'create%s' % workflowName)
            workflow = wfMethod(self, workflowName)
            workflowTool._setObject(workflowName, workflow)
        else:
            print >> out, '%s already in workflows.' % workflowName
        # Link the workflow to the current content type
        workflowTool.setChainForPortalTypes([contentType], workflowName)
    return workflowTool

def uninstallWorkflows(self, package, out):
    """Deinstall the workflows."""
    pass
