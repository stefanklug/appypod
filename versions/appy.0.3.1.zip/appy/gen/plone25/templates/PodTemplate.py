# -*- coding: utf-8 -*-
#
# GNU General Public License (GPL)
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
# 02110-1301, USA.
#

from AccessControl import ClassSecurityInfo
from DateTime import DateTime
from Products.Archetypes.atapi import *
from Products.<!applicationName!>.config import HAS_POD, mimeTypes
import os, os.path, time
from StringIO import StringIO
from Products.CMFCore.Expression import Expression, createExprContext
import logging
logger = logging.getLogger('<!applicationName!>')
from Extensions.appyMixins import ClassMixin
from Extensions.appyWrappers import <!wrapperClass!>
import <!applicationName!>

schema = Schema((<!fields!>
),
)
fullSchema = BaseSchema.copy() + schema.copy()

# ------------------------------------------------------------------------------
class PodError(Exception): pass

# ------------------------------------------------------------------------------
def getOsTempFolder():
    tmp = '/tmp'
    if os.path.exists(tmp) and os.path.isdir(tmp):
        res = tmp
    elif os.environ.has_key('TMP'):
        res = os.environ['TMP']
    elif os.environ.has_key('TEMP'):
        res = os.environ['TEMP']
    else:
        raise "Sorry, I can't find a temp folder on your machine."
    return res

# Error-related constants ------------------------------------------------------
POD_ERROR = 'An error occurred while generating the document. Please check ' \
            'the following things if you wanted to generate the document in ' \
            'PDF, DOC or RTF: (1) OpenOffice is started in server mode on ' \
            'the port you should have specified in the PloneMeeting ' \
            'configuration (go to Site setup-> PloneMeeting configuration); ' \
            '(2) if the Python interpreter running Zope and ' \
            'Plone is not able to discuss with OpenOffice (it does not have ' \
            '"uno" installed - check it by typing "import uno" at the Python ' \
            'prompt) please specify, in the PloneMeeting configuration, ' \
            'the path to a UNO-enabled Python interpreter (ie, the Python ' \
            'interpreter included in the OpenOffice distribution, or, if ' \
            'your server runs Ubuntu, the standard Python interpreter ' \
            'installed in /usr/bin/python). Here is the error as reported ' \
            'by the appy.pod library:\n\n %s'
DELETE_TEMP_DOC_ERROR = 'A temporary document could not be removed. %s.'

class <!applicationName!>PodTemplate(BaseContent, ClassMixin):
    '''POD template.'''
    security = ClassSecurityInfo()
    __implements__ = (getattr(BaseContent,'__implements__',()),)

    archetype_name = '<!applicationName!>PodTemplate'
    meta_type = '<!applicationName!>PodTemplate'
    portal_type = '<!applicationName!>PodTemplate'
    allowed_content_types = []
    filter_content_types = 0
    global_allow = 1
    #content_icon = '<!applicationName!>PodTemplate.gif'
    immediate_view = '<!applicationName!>_appy_view'
    default_view = '<!applicationName!>_appy_view'
    suppl_views = ()
    typeDescription = "<!applicationName!>PodTemplate"
    typeDescMsgId = '<!applicationName!>_edit_descr'
    _at_rename_after_creation = True
    wrapperClass = <!wrapperClass!>
    schema = fullSchema

<!commonMethods!>

    security.declarePublic('generateDocument')
    def generateDocument(self, obj):
        '''Generates a document from this template, for object p_obj.'''
        appySelf = self._appy_getWrapper(force=True)
        if not HAS_POD:
            raise PodError(
                obj.utranslate('<!applicationName!>_pod_not_installed',
                               domain='<!applicationName!>'))
        # Temporary file where to generate the result
        tempFileName = '%s/%s_%f.%s' % (
            getOsTempFolder(), obj.UID(), time.time(), self.getPodFormat())
        # Define parameters to pass to the appy.pod renderer
        currentUser = self.portal_membership.getAuthenticatedMember()
        podContext = {'self': obj._appy_getWrapper(force=True),
                      'user': currentUser,
                      'podTemplate': appySelf,
                      'now': DateTime(),
                      'projectFolder': os.path.dirname(<!applicationName!>.__file__)
                      }
        rendererParams = {'template': StringIO(appySelf.podTemplate),
                          'context': podContext,
                          'result': tempFileName }
        if appySelf.tool.unoEnabledPython:
            rendererParams['pythonWithUnoPath'] = appySelf.tool.unoEnabledPython
        if appySelf.tool.openOfficePort:
            rendererParams['ooPort'] = appySelf.tool.openOfficePort
        # Launch the renderer
        import appy.pod
        try:
            renderer = appy.pod.renderer.Renderer(**rendererParams)
            renderer.run()
        except appy.pod.PodError, pe:
            if not os.path.exists(tempFileName):
                # In some (most?) cases, when OO returns an error, the result is
                # nevertheless generated.
                raise PodError(POD_ERROR % str(pe))
        # Open the temp file on the filesystem
        f = file(tempFileName, 'rb')
        forBrowser = True
        if forBrowser:
            # Create a OFS.Image.File object that will manage correclty HTTP
            # headers, etc.
            from OFS.Image import File
            theFile = File('dummyId', 'dummyTitle', f,
                           content_type=mimeTypes[appySelf.podFormat])
            res = theFile.index_html(self.REQUEST, self.REQUEST.RESPONSE)
        else:
            # I must return the raw document content.
            res = f.read()
        f.close()
        # Returns the doc and removes the temp file
        try:
            os.remove(tempFileName)
        except OSError, oe:
            logger.warn(DELETE_TEMP_DOC_ERROR % str(oe))
        except IOError, ie:
            logger.warn(DELETE_TEMP_DOC_ERROR % str(ie))
        return res
<!methods!>

registerType(<!applicationName!>PodTemplate, '<!applicationName!>')
