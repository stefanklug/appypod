from appy.gen import *

class Radio:
    abstract = True
    name = String()
