import os.path
import appy

def getAppyPath():
    return os.path.dirname(appy.__file__)

