#!/bin/sh
python2.4.4 /home/gde/appy/gen/generator.py AppyMeeting.py plone25 /home/gde/ZopeInstance1/Products
python2.4.4 /home/gde/appy/gen/generator.py ZopeComponent.py plone25 /home/gde/ZopeInstance1/Products
python2.4.4 /home/gde/appy/gen/generator.py Zzz.py plone25 /home/gde/ZopeInstance1/Products
