This folder contains some example Appy applications used for testing purposes.

Directly in the folder, you have the application "AppyMeeting" which consists in
a single Python file (module AppyMeeting.py), a POD template for producing
documents (Meeting.odt) and a script for generating an application from it.

In sub-folder AppyCar, you have a more complex application that is structured
as a Python package (a hierarchy of folders).

