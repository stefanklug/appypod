#!/bin/sh
python2.4.4 /home/gde/appy/gen/generator.py . plone25 /home/gde/ZopeInstance2/Products
