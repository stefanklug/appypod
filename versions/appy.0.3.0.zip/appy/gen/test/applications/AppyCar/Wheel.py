from appy.gen import *

class Wheel:
    title = String(multiplicity=(1,1))
    description = String(format=String.XHTML)

