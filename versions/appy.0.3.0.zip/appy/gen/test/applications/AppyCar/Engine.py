from appy.gen import *

class Engine:
    engineType = String()
    description = String(format=String.XHTML)
    pod = True
