# ------------------------------------------------------------------------------
import os, os.path, sys, parser, symbol, token
from optparse import OptionParser
from appy.gen import Type, State, Config, Tool, Flavour
from appy.gen.utils import produceNiceMessage
from appy.shared.utils import FolderDeleter

# ------------------------------------------------------------------------------
class GeneratorError(Exception): pass

# I need the following classes to parse Python classes and find in which
# order the attributes are defined. --------------------------------------------
class AstMatcher:
    '''Allows to find a given pattern within an ast (part).'''
    def _match(pattern, node):
        res = None
        if pattern[0] == node[0]:
            # This level matches
            if len(pattern) == 1:
                return node
            else:
                if type(node[1]) == tuple:
                    return AstMatcher._match(pattern[1:], node[1])
        return res
    _match = staticmethod(_match)
    def match(pattern, node):
        res = []
        for subNode in node[1:]:
            # Do I find the pattern among the subnodes ?
            occurrence = AstMatcher._match(pattern, subNode)
            if occurrence:
                res.append(occurrence)
        return res
    match = staticmethod(match)

# ------------------------------------------------------------------------------
class AstClass:
    '''Python class.'''
    def __init__(self, node):
        # Link to the Python ast node
        self.node = node
        self.name = node[2][1]
        self.attributes = [] # We are only interested in parsing static
        # attributes to now their order
        if sys.version_info[:2] >= (2,5):
            self.statementPattern = (
              symbol.stmt, symbol.simple_stmt, symbol.small_stmt,
              symbol.expr_stmt, symbol.testlist, symbol.test, symbol.or_test, 
              symbol.and_test, symbol.not_test, symbol.comparison, symbol.expr,
              symbol.xor_expr, symbol.and_expr, symbol.shift_expr, 
              symbol.arith_expr, symbol.term, symbol.factor, symbol.power)
        else:
            self.statementPattern = (
              symbol.stmt, symbol.simple_stmt, symbol.small_stmt,
              symbol.expr_stmt, symbol.testlist, symbol.test, symbol.and_test,
              symbol.not_test, symbol.comparison, symbol.expr, symbol.xor_expr,
              symbol.and_expr, symbol.shift_expr, symbol.arith_expr,
              symbol.term, symbol.factor, symbol.power)
        for subNode in node[1:]:
            if subNode[0] == symbol.suite:
                # We are in the class body
                self.getStaticAttributes(subNode)

    def getStaticAttributes(self, classBody):
        statements = AstMatcher.match(self.statementPattern, classBody)
        for statement in statements:
            if len(statement) == 2 and statement[1][0] == symbol.atom and \
               statement[1][1][0] == token.NAME:
                attrName = statement[1][1][1]
                self.attributes.append(attrName)

    def __repr__(self):
        return '<class %s has attrs %s>' % (self.name, str(self.attributes))

# ------------------------------------------------------------------------------
class Ast:
    '''Python AST.'''
    classPattern = (symbol.stmt, symbol.compound_stmt, symbol.classdef)
    def __init__(self, pyFile):
        f = file(pyFile)
        fContent = f.read()
        f.close()
        fContent = fContent.replace('\r', '')
        ast = parser.suite(fContent).totuple()
        # Get all the classes defined within this module.
        self.classes = {}
        classNodes = AstMatcher.match(self.classPattern, ast)
        for node in classNodes:
            astClass = AstClass(node)
            self.classes[astClass.name] = astClass

# ------------------------------------------------------------------------------
class Generator:
    '''Abstract base class for building a generator.'''
    def __init__(self, application, outputFolder):
        self.application = application
        # Determine application name
        self.applicationName = os.path.basename(application)
        if application.endswith('.py'):
            self.applicationName = self.applicationName[:-3]
        self.outputFolder = '%s/%s' % (outputFolder, self.applicationName)
        self.initialize()
        self.config = Config.getDefault()

    def determineAppyType(self, klass):
        '''Is p_klass an Appy class ? An Appy workflow? None of this ?
           If it (or a parent) declares at least one appy type definition,
           it will be considered an Appy class. If it (or a parent) declares at
           least one state definition, it will be considered an Appy
           workflow.'''
        res = 'none'
        for attrValue in klass.__dict__.itervalues():
            if isinstance(attrValue, Type):
                res = 'class'
            elif isinstance(attrValue, State):
                res = 'workflow'
        if not res:
            for baseClass in klass.__bases__:
                baseClassType = self.determineAppyType(baseClass)
                if baseClassType != 'none':
                    res = baseClassType
                    break
        return res

    IMPORT_ERROR = 'Warning: error while importing module %s (%s)'
    SYNTAX_ERROR = 'Warning: error while parsing module %s (%s)'
    def walkModule(self, moduleName):
        '''Visits a given (sub-*)module into the application.'''
        try:
            exec 'import %s' % moduleName
            exec 'moduleObj = %s' % moduleName
            moduleFile = moduleObj.__file__
            if moduleFile.endswith('.pyc'):
                moduleFile = moduleFile[:-1]
            astClasses = Ast(moduleFile).classes
        except ImportError, ie:
            # True import error or, simply, this is a simple folder within
            # the application, not a sub-module.
            print self.IMPORT_ERROR % (moduleName, str(ie))
            return
        except SyntaxError, se:
            print self.SYNTAX_ERROR % (moduleName, str(se))
            return
        classType = type(Generator)
        # Find all classes in this module
        for moduleElemName in moduleObj.__dict__.keys():
            exec 'moduleElem = moduleObj.%s' % moduleElemName
            if (type(moduleElem) == classType) and \
               (moduleElem.__module__ == moduleObj.__name__):
                # We have found a Python class definition in this module.
                appyType = self.determineAppyType(moduleElem)
                if appyType != 'none':
                    print 'Generating %s.%s (gen-%s)...' % \
                        (moduleName, moduleElem.__name__, appyType)
                    # Produce a list of static class attributes (in the order
                    # of their definition).
                    attrs = astClasses[moduleElem.__name__].attributes
                    if appyType == 'class':
                        ct = 'class'
                        if issubclass(moduleElem, Tool):
                            ct = 'tool'
                        elif issubclass(moduleElem, Flavour):
                            ct = 'flavour'
                        self.generateClass(moduleElem, attrs, ct)
                    elif appyType == 'workflow':
                        self.generateWorkflow(moduleElem, attrs)
            elif isinstance(moduleElem, Config):
                self.config = moduleElem

        # Walk potential sub-modules
        if moduleFile.find('__init__.py') != -1:
            # Potentially, sub-modules exist
            moduleFolder = os.path.dirname(moduleFile)
            for elem in os.listdir(moduleFolder):
                subModuleName, ext = os.path.splitext(elem)
                if ((ext == '.py') and (subModuleName != '__init__')) or \
                   os.path.isdir(os.path.join(moduleFolder, subModuleName)):
                    # Submodules may be sub-folders or Python files
                    subModuleName = '%s.%s' % (moduleName, subModuleName)
                    self.walkModule(subModuleName)

    def walkApplication(self):
        '''This method walks into the application, finds classes in it and
           calls self.manageClass for each encountered class.'''
        # Where is the application located ?
        containingFolder = os.path.dirname(self.application)
        sys.path.append(containingFolder)
        # What is the name of the application ?
        appName = os.path.basename(self.application)
        if os.path.isfile(self.application):
            appName = os.path.splitext(appName)[0]
        self.walkModule(appName)
        sys.path.pop()

    def generateClass(self, klass, orderedAttributes, classType):
        '''This method is called whenever a Python class declaring Appy type
           definition(s) is encountered within the application. p_classType may
           be "class" (p_klass is a standard class in the application), "tool"
           (p_klass is a Tool subclass for extending the tool definition) or
           "flavour" (p_klass is a Flavour subclass for extending the flavour
           definition).'''
        raise 'Override me.'

    def generateWorkflow(self, workflow, orderedAttributes):
        '''This method is called whenever a Python class declaring states and
           transitions is encountered within the application.'''
        pass

    def initialize(self):
        '''Called before the old product is removed (if any), in __init__.'''

    def finalize(self):
        '''Called at the end of the generation process.'''

    def run(self):
        self.walkApplication()
        self.finalize()
        print 'Done.'

# ------------------------------------------------------------------------------
ERROR_CODE = 1
VALID_PRODUCT_TYPES = ('plone25',)
APP_NOT_FOUND = 'Application not found at %s.'
WRONG_NG_OF_ARGS = 'Wrong number of arguments.'
WRONG_OUTPUT_FOLDER = 'Output folder not found. Please create it first.'
PRODUCT_TYPE_ERROR = 'Wrong product type. Product type may be one of the ' \
                     'following: %s' % str(VALID_PRODUCT_TYPES)
class GeneratorScript:
    '''usage: python  generate.py app productType outputFolder
       "app"          is the path to your Appy application, which may be a
                      Python module (= a file than ends with .py) or a Python
                      package (= a folder containing a file named __init__.py).
                      Your app may reside anywhere (but it needs to be
                      accessible by the underlying application server, ie Zope),
                      excepted within the generated product. Typically, if you
                      generate a Plone product, it may reside within
                      <yourZopeInstance>/lib/python, but not within the
                      generated product (typically stored in
                      <yourZopeInstance>/Products).
       "productType"  is the kind of product you want to generate
                      (currently, only "plone25" is supported; in the near
                      future, this target will also produce Plone 3-compliant
                      code that will still work with Plone 2.5).
       "outputFolder" is the folder where the product will be generated.
                      For example, if you specify /my/output/folder for your
                      application /home/gde/MyApp.py, this script will create
                      a folder /my/output/folder/MyApp and put in it the
                      generated product.

       Example
       -------
       + Generating a Plone product
       ++++++++++++++++++++++++++++
       In your Zope instance named myZopeInstance, create a folder
       "myZopeInstance/lib/python/MyApp". Create into it your Appy application
       (we suppose here that it is a Python package, containing a __init__.py
       file and other files). Then, chdir into this folder and type
       "python <appyPath>/gen/generator.py . plone25 ../../../Products" and the
       product will be generated in myZopeInstance/Products/MyApp.
       "python" must refer to a Python interpreter that knows package appy.'''
    def generateProduct(self, application, productType, outputFolder):
        exec 'from appy.gen.%s.generator import Generator' % productType
        Generator(application, outputFolder).run()
    def manageArgs(self, options, args):
        # Check number of args
        if len(args) != 3:
            print WRONG_NG_OF_ARGS
            print GeneratorScript.__doc__
            sys.exit(ERROR_CODE)
        # Check productType
        if args[1] not in VALID_PRODUCT_TYPES:
            print PRODUCT_TYPE_ERROR
            sys.exit(ERROR_CODE)
        # Check existence of application
        if not os.path.exists(args[0]):
            print APP_NOT_FOUND % args[0]
            sys.exit(ERROR_CODE)
        # Check existence of outputFolder basic type
        if not os.path.exists(args[2]):
            print WRONG_OUTPUT_FOLDER
            sys.exit(ERROR_CODE)
        # Convert all paths in absolute paths
        for i in (0,2):
            args[i] = os.path.abspath(args[i])
    def run(self):
        optParser = OptionParser(usage=GeneratorScript.__doc__)
        (options, args) = optParser.parse_args()
        try:
            self.manageArgs(options, args)
            print 'Generating product in %s...' % args[2]
            self.generateProduct(*args)
        except GeneratorError, ge:
            sys.stderr.write(str(ge))
            sys.stderr.write('\n')
            optParser.print_help()
            sys.exit(ERROR_CODE)

# ------------------------------------------------------------------------------
if __name__ == '__main__':
    GeneratorScript().run()
# ------------------------------------------------------------------------------
