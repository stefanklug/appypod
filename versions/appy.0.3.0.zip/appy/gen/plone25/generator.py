'''This file contains the main Generator class used for generating a
   Plone 2.5-compliant product.'''

# ------------------------------------------------------------------------------
import os, os.path, re, sys
import appy.gen
from appy.gen import *
from appy.gen.po import PoMessage, PoFile, PoParser
from appy.gen.generator import Generator as AbstractGenerator
from model import ModelClass, PodTemplate, Flavour, Tool
from descriptors import ArchetypeFieldDescriptor, ArchetypesClassDescriptor, \
                        WorkflowDescriptor, ToolClassDescriptor, \
                        FlavourClassDescriptor, PodTemplateClassDescriptor, \
                        CustomToolClassDescriptor, CustomFlavourClassDescriptor

# ------------------------------------------------------------------------------
class Generator(AbstractGenerator):
    '''This generator generates a Plone 2.5-compliant product from a given
       appy application.'''
    poExtensions = ('.po', '.pot')

    def __init__(self, *args, **kwargs):
        Flavour._appy_clean()
        AbstractGenerator.__init__(self, *args, **kwargs)
        self.templatesFolder = os.path.join(os.path.dirname(
            appy.gen.plone25.__file__), 'templates')
        # Generated Appy classes
        self.classes = [] # ~[ArchetypesClassDescriptor]~
        self.workflows = [] # ~[WorkflowDescriptor]~
        # i18n labels to generate
        self.labels = [] # In the application domain
        self.toolName = '%sTool' % self.applicationName
        self.flavourName = '%sFlavour' % self.applicationName
        self.toolInstanceName = 'portal_%s' % self.applicationName.lower()
        self.podTemplateName = '%sPodTemplate' % self.applicationName
        self.portletName = '%s_portlet' % self.applicationName.lower()
        self.queryName = '%s_query' % self.applicationName.lower()
        self.skinsFolder = 'skins/%s' % self.applicationName
        # This dict contains a series of replacements that need to be applied
        # to file templates to generate files.
        f = file(os.path.join(self.templatesFolder, 'CommonMethods.py'))
        commonMethods = f.read().replace(
            '<!applicationName!>', self.applicationName)
        f.close()
        self.repls = {'applicationName': self.applicationName,
                      'applicationPath': os.path.dirname(self.application),
                      'toolName': self.toolName,
                      'flavourName': self.flavourName,
                      'portletName': self.portletName,
                      'queryName': self.queryName,
                      'toolInstanceName': self.toolInstanceName,
                      'podTemplateName': self.podTemplateName,
                      'macros': '%s_macros' % self.applicationName.lower(),
                      'commonMethods': commonMethods}
        # Predefined class descriptors
        self.toolDescr = None
        self.flavourDescr = None
        self.podTemplateDescr = None
        # Does the user have specific Tool and/or Flavour class in its
        # application?
        self.customToolDescr = None
        self.customFlavourDescr = None
        self.referers = {}

    versionRex = re.compile('(.*?\s+build)\s+(\d+)')
    def initialize(self):
        # Determine version number of the Plone product
        self.version = '0.1 build 1'
        versionTxt = os.path.join(self.outputFolder, 'version.txt')
        if os.path.exists(versionTxt):
            f = file(versionTxt)
            oldVersion = f.read().strip()
            f.close()
            res = self.versionRex.search(oldVersion)
            self.version = res.group(1) + ' ' + str(int(res.group(2))+1)
        # Existing i18n files
        self.i18nFiles = {} #~{p_fileName: PoFile}~
        # Retrieve existing i18n files if any
        i18nFolder = os.path.join(self.outputFolder, 'i18n')
        if os.path.exists(i18nFolder):
            for fileName in os.listdir(i18nFolder):
                name, ext = os.path.splitext(fileName)
                if ext in self.poExtensions:
                    poParser = PoParser(os.path.join(i18nFolder, fileName))
                    self.i18nFiles[fileName] = poParser.parse()

    def finalize(self):
        # Some useful aliases
        msg = PoMessage
        app = self.applicationName
        # Some global i18n messages
        poMsg = msg(app, '', app); poMsg.produceNiceDefault()
        self.labels += [poMsg,
            msg('workflow_state', '', msg.WORKFLOW_STATE),
            msg('root_type', '', msg.ROOT_TYPE),
            msg('workflow_comment', '', msg.WORKFLOW_COMMENT),
            msg('choose_a_value', '', msg.CHOOSE_A_VALUE),
            msg('choose_a_doc', '', msg.CHOOSE_A_DOC),
            msg('min_ref_violated', '', msg.MIN_REF_VIOLATED),
            msg('max_ref_violated', '', msg.MAX_REF_VIOLATED),
            msg('no_ref', '', msg.REF_NO),
            msg('add_ref', '', msg.REF_ADD),
            msg('ref_name', '', msg.REF_NAME),
            msg('ref_actions', '', msg.REF_ACTIONS),
            msg('move_up', '', msg.REF_MOVE_UP),
            msg('move_down', '', msg.REF_MOVE_DOWN),
            msg('query_create', '', msg.QUERY_CREATE),
            msg('query_no_result', '', msg.QUERY_NO_RESULT),
            msg('query_consult_all', '', msg.QUERY_CONSULT_ALL),
            msg('ref_invalid_index', '', msg.REF_INVALID_INDEX),
            msg('bad_int', '', msg.BAD_INT),
            msg('bad_float', '', msg.BAD_FLOAT),
            msg('bad_email', '', msg.BAD_EMAIL),
            msg('bad_url', '', msg.BAD_URL),
            msg('bad_alphanumeric', '', msg.BAD_ALPHANUMERIC),
        ]
        # Create basic files (config.py, Install.py, etc)
        self.generateAppyReference()
        self.generateTool()
        self.generateConfig()
        self.generateInit()
        self.generateInstall()
        self.generateInstallWorkflows()
        self.generateWrappers()
        self.generatePortlet()
        if self.config.frontPage == True:
            self.labels.append(msg('front_page_text', '', msg.FRONT_PAGE_TEXT))
            self.copyFile('frontPage.pt', self.repls,
                          destFolder=self.skinsFolder,
                          destName='%sFrontPage.pt' % self.applicationName)
        self.copyFile('configure.zcml', self.repls)
        self.copyFile('import_steps.xml', self.repls,
                      destFolder='profiles/default')
        self.copyFile('ProfileInit.py', self.repls, destFolder='profiles',
                      destName='__init__.py')
        self.copyFile('appyMixins.py', self.repls, destFolder='Extensions')
        self.copyFile('tool.gif', {})
        self.copyFile('Macros.pt', self.repls, destFolder=self.skinsFolder,
                      destName='%s_macros.pt' % self.applicationName.lower())
        self.copyFile('appy_view.pt', self.repls, destFolder=self.skinsFolder,
                      destName='%s_appy_view.pt' % self.applicationName)
        self.copyFile('appy_edit.cpt', self.repls, destFolder=self.skinsFolder,
                      destName='%s_appy_edit.cpt' % self.applicationName)
        self.copyFile('appy_edit.cpt.metadata', self.repls,
                      destFolder=self.skinsFolder,
                      destName='%s_appy_edit.cpt.metadata'%self.applicationName)
        self.copyFile('Styles.css.dtml', self.repls, destFolder=self.skinsFolder,
                      destName = '%s.css.dtml' % self.applicationName)
        self.copyFile('do.py', self.repls, destFolder=self.skinsFolder,
                      destName='%s_do.py' % self.applicationName)
        self.copyFile('colophon.pt', self.repls, destFolder=self.skinsFolder)
        self.copyFile('footer.pt', self.repls, destFolder=self.skinsFolder)
        # Create version.txt
        f = open(os.path.join(self.outputFolder, 'version.txt'), 'w')
        f.write(self.version)
        f.close()
        # Make Extensions a Python package
        for moduleFolder in ('Extensions',):
            initFile = '%s/%s/__init__.py' % (self.outputFolder, moduleFolder)
            if not os.path.isfile(initFile):
                f = open(initFile, 'w')
                f.write('')
                f.close()
        # Decline i18n labels into versions for child classes
        for classDescr in self.classes:
            for poMsg in classDescr.labelsToPropagate:
                for childDescr in classDescr.getChildren(self.classes):
                    childMsg = poMsg.clone(classDescr.name, childDescr.name)
                    if childMsg not in self.labels:
                        self.labels.append(childMsg)

        # Generate i18n pot file
        potFileName = '%s.pot' % self.applicationName
        if self.i18nFiles.has_key(potFileName):
            potFile = self.i18nFiles[potFileName]
        else:
            fullName = os.path.join(self.outputFolder, 'i18n/%s' % potFileName)
            potFile = PoFile(fullName)
            self.i18nFiles[potFileName] = potFile
        potFile.update(self.labels)
        potFile.generate()
        # Generate i18n po files
        for language in self.config.languages:
            # I must generate (or update) a po file for the language(s)
            # specified in the configuration.
            poFileName = potFile.getPoFileName(language)
            if self.i18nFiles.has_key(poFileName):
                poFile = self.i18nFiles[poFileName]
            else:
                fullName = os.path.join(self.outputFolder,
                                        'i18n/%s' % poFileName)
                poFile = PoFile(fullName)
                self.i18nFiles[poFileName] = poFile
            poFile.update(potFile.messages)
            poFile.generate()
        # Generate i18n po files for other potential files
        for poFile in self.i18nFiles.itervalues():
            if not poFile.generated:
                poFile.generate()

    ploneRoles = ('Manager', 'Member', 'Owner', 'Reviewer')
    def getAllUsedRoles(self, appOnly=False):
        '''Produces a list of all the roles used within all workflows defined
           in this application. If p_appOnly is True, it returns only roles
           which are specific to this application (ie it removes predefined
           Plone roles like Member, Manager, etc.'''
        res = []
        for wfDescr in self.workflows:
            # Browse states and transitions
            for attr in dir(wfDescr.klass):
                attrValue = getattr(wfDescr.klass, attr)
                if isinstance(attrValue, State) or \
                   isinstance(attrValue, Transition):
                    res += attrValue.getUsedRoles()
        res = list(set(res))
        if appOnly:
            for ploneRole in self.ploneRoles:
                if ploneRole in res:
                    res.remove(ploneRole)
        return res

    def addReferer(self, fieldDescr, relationship):
        '''p_fieldDescr is a Ref type definition. We will create in config.py a
           dict that lists all back references, by type.'''
        k = fieldDescr.appyType.klass
        if issubclass(k, ModelClass):
            refClassName = self.applicationName + k.__name__
        elif issubclass(k, appy.gen.Tool):
            refClassName = '%sTool' % self.applicationName
        elif issubclass(k, appy.gen.Flavour):
            refClassName = '%sFlavour' % self.applicationName
        else:
            refClassName = ArchetypesClassDescriptor.getClassName(k)
        if not self.referers.has_key(refClassName):
            self.referers[refClassName] = []
        self.referers[refClassName].append( (fieldDescr, relationship))

    def copyFile(self, fileName, replacements, destName=None, destFolder=None):
        '''This method will copy p_fileName to self.outputFolder (or in a
           subFolder if p_destFolder is given) after having replaced all
           p_replacements.'''
        # Get the file template
        f = file(os.path.join(self.templatesFolder, fileName))
        fileContent = f.read()
        f.close()
        if not fileName.endswith('.png'):
            for rKey, rValue in replacements.iteritems():
                fileContent = fileContent.replace('<!%s!>' % rKey, str(rValue))
        # Copy the result to self.outputFolder
        destFile = fileName
        if destName:
            destFile = destName
        if destFolder:
            destFile = '%s/%s' % (destFolder, destFile)
        # Create the dest folder if it does not exist
        absDestFolder = self.outputFolder
        if destFolder:
            absDestFolder = os.path.join(self.outputFolder, destFolder)
        if not os.path.exists(absDestFolder):
            os.makedirs(absDestFolder)
        # Create the file
        f = file(os.path.join(self.outputFolder, destFile), 'w')
        f.write(fileContent)
        f.close()

    def generatePortlet(self):
        rootClasses = ''
        for classDescr in self.classes:
            if classDescr.isRoot():
                rootClasses += "'%s'," % classDescr.name
        repls = self.repls.copy()
        repls['rootClasses'] = rootClasses
        self.copyFile('Portlet.pt', repls, destName='%s.pt' % self.portletName,
                      destFolder=self.skinsFolder)
        self.copyFile('Query.pt', repls, destName='%s.pt' % self.queryName,
                      destFolder=self.skinsFolder)

    def generateConfig(self):
        # Compute referers
        referers = ''
        for className, refInfo in self.referers.iteritems():
            referers += '"%s":[' % className
            for fieldDescr, relationship in refInfo:
                refClass = fieldDescr.classDescr.klass
                if issubclass(refClass, ModelClass):
                    refClassName = 'Extensions.appyWrappers.%s' % \
                                   refClass.__name__
                else:
                    refClassName = '%s.%s' % (refClass.__module__,
                                              refClass.__name__)
                referers += '(%s.%s' % (refClassName, fieldDescr.fieldName)
                referers += ',"%s"' % relationship
                referers += '),'
            referers += '],\n'
        # Compute workflow instances initialisation
        wfInit = ''
        for workflowDescr in self.workflows:
            k = workflowDescr.klass
            className = '%s.%s' % (k.__module__, k.__name__)
            wfInit += 'wf = %s()\n' % className
            wfInit += 'wf._transitionsMapping = {}\n'
            for transition in workflowDescr.getTransitions():
                tName = workflowDescr.getNameOf(transition)
                tNames = workflowDescr.getTransitionNamesOf(tName, transition)
                for trName in tNames:
                    wfInit += 'wf._transitionsMapping["%s"] = wf.%s\n' % \
                              (trName, tName)
            # We need a new attribute that stores states in order
            wfInit += 'wf._states = []\n'
            for stateName in workflowDescr.getStateNames(ordered=True):
                wfInit += 'wf._states.append("%s")\n' % stateName
            wfInit += 'workflowInstances[%s] = wf\n' % className
        # Compute imports
        imports = []
        classDescrs = self.classes[:]
        if self.customToolDescr:
            classDescrs.append(self.customToolDescr)
        if self.customFlavourDescr:
            classDescrs.append(self.customFlavourDescr)
        for classDescr in (classDescrs + self.workflows):
            theImport = 'import %s' % classDescr.klass.__module__
            if theImport not in imports:
                imports.append(theImport)
        # Compute list of add permissions
        addPermissions = ''
        for classDescr in self.classes:
            addPermissions += '    "%s":"%s: Add %s",\n' % (classDescr.name,
                self.applicationName, classDescr.name)
        repls = self.repls.copy()
        # Compute list of used roles for registering them if needed
        repls['roles'] = ','.join(['"%s"' % r for r in \
                                  self.getAllUsedRoles(appOnly=True)])
        repls['referers'] = referers
        repls['workflowInstancesInit'] = wfInit
        repls['imports'] = '\n'.join(imports)
        repls['defaultAddRoles'] = ','.join(
            ['"%s"' % r for r in self.config.defaultCreators])
        repls['addPermissions'] = addPermissions
        self.copyFile('config.py', repls)

    def generateInit(self):
        # Compute imports
        imports = ['    import %s' % self.toolName,
                   '    import %s' % self.flavourName,
                   '    import %s' % self.podTemplateName]
        for c in self.classes:
            importDef = '    import %s' % c.name
            if importDef not in imports:
                imports.append(importDef)
        repls = self.repls.copy()
        repls['imports'] = '\n'.join(imports)
        self.copyFile('__init__.py', repls)

    def generateInstall(self):
        # Compute lists of class names
        allClassNames = '"%s",' % self.flavourName
        allClassNames += '"%s",' % self.podTemplateName
        appClassNames = ','.join(['"%s"' % c.name for c in self.classes])
        allClassNames += appClassNames
        # Compute imports
        imports = []
        for classDescr in self.classes:
            theImport = 'import %s' % classDescr.klass.__module__
            if theImport not in imports:
                imports.append(theImport)
        # Compute list of application classes
        appClasses = []
        for classDescr in self.classes:
            k = classDescr.klass
            appClasses.append('%s.%s' % (k.__module__, k.__name__))
        # Compute classes whose instances must not be catalogued.
        catalogMap = ''
        blackClasses = [self.toolName, self.flavourName, self.podTemplateName]
        for blackClass in blackClasses:
            catalogMap += "    catalogmap['%s'] = {}\n" % blackClass
            catalogMap += "    catalogmap['%s']['black'] = " \
                          "['portal_catalog']\n" % blackClass
        # Generate the resulting file.
        repls = self.repls.copy()
        repls['allClassNames'] = allClassNames
        repls['appClassNames'] = appClassNames
        repls['catalogMap'] = catalogMap
        repls['imports'] = '\n'.join(imports)
        repls['appClasses'] = "[%s]" % ','.join(appClasses)
        repls['minimalistPlone'] = self.config.minimalistPlone
        repls['appFrontPage'] = self.config.frontPage == True
        self.copyFile('Install.py', repls, destFolder='Extensions')

    def generateInstallWorkflows(self):
        # Generate workflows
        workflows = ''
        for classDescr in self.classes:
            if hasattr(classDescr.klass, 'workflow'):
                wfName = WorkflowDescriptor.getWorkflowName(
                    classDescr.klass.workflow)
                className = ArchetypesClassDescriptor.getClassName(
                    classDescr.klass)
                workflows += '"%s":"%s",\n    ' % (className, wfName)
        repls = self.repls.copy()
        repls['workflows'] = workflows
        self.copyFile('InstallWorkflows.py', repls, destFolder='Extensions')

    def generateWrapperProperty(self, attrName, appyType):
        # Generate getter
        res = '    def get_%s(self):\n' % attrName
        blanks = ' '*8
        if isinstance(appyType, Ref):
            res += blanks + 'return self.o._appy_getRefs("%s", ' \
                   'noListIfSingleObj=True)\n' % attrName
        elif isinstance(appyType, Computed):
            res += blanks + 'appyType = getattr(self.klass, "%s")\n' % attrName
            res += blanks + 'return self.o._appy_getComputedValue(' \
                            'appyType.__dict__)\n'
        else:
            getterName = 'get%s%s' % (attrName[0].upper(), attrName[1:])
            if attrName in ArchetypeFieldDescriptor.specialParams:
                getterName = attrName.capitalize()
            res += blanks + 'return self.o.%s()\n' % getterName
        res += '    %s = property(get_%s)\n\n' % (attrName, attrName)
        return res

    def generateWrapperPropertyBack(self, attrName, rel):
        '''Generates a wrapper property for accessing the back reference named
           p_attrName through Archetypes relationship p_rel.'''
        res = '    def get_%s(self):\n' % attrName
        blanks = ' '*8
        res += blanks + 'return self.o._appy_getRefsBack("%s", "%s", ' \
                   'noListIfSingleObj=True)\n' % (attrName, rel)
        res += '    %s = property(get_%s)\n\n' % (attrName, attrName)
        return res

    def getClassesInOrder(self, allClasses):
        '''When generating wrappers, classes mut be dumped in order (else, it
           generates forward references in the Python file, that does not
           compile).'''
        res = [] # Appy class descriptors
        resClasses = [] # Corresponding real Python classes
        for classDescr in allClasses:
            klass = classDescr.klass
            if not klass.__bases__ or \
               (klass.__bases__[0].__name__ == 'ModelClass'):
                # This is a root class. We dump it at the begin of the file.
                res.insert(0, classDescr)
                resClasses.insert(0, klass)
            else:
                # If a child of this class is already present, we must insert
                # this klass before it.
                lowestChildIndex = sys.maxint
                for resClass in resClasses:
                    if klass in resClass.__bases__:
                        lowestChildIndex = min(lowestChildIndex,
                                               resClasses.index(resClass))
                if lowestChildIndex != sys.maxint:
                    res.insert(lowestChildIndex, classDescr)
                    resClasses.insert(lowestChildIndex, klass)
                else:
                    res.append(classDescr)
                    resClasses.append(klass)
        return res

    def generateWrappers(self):
        # We must generate imports and wrapper definitions
        imports = []
        wrappers = []
        allClasses = self.classes[:]
        # Add predefined classes (Tool, Flavour, PodTemplate)
        allClasses += [self.toolDescr, self.flavourDescr, self.podTemplateDescr]
        if self.customToolDescr:
            allClasses.append(self.customToolDescr)
        if self.customFlavourDescr:
            allClasses.append(self.customFlavourDescr)
        for c in self.getClassesInOrder(allClasses):
            if not c.predefined:
                moduleImport = 'import %s' % c.klass.__module__
                if moduleImport not in imports:
                    imports.append(moduleImport)
            # Determine parent wrapper and class
            parentWrapper = 'AbstractWrapper'
            parentClass = '%s.%s' % (c.klass.__module__, c.klass.__name__)
            if c.predefined:
                parentClass = c.klass.__name__
            if c.klass.__bases__:
                baseClassName = c.klass.__bases__[0].__name__
                for k in allClasses:
                    if k.klass.__name__ == baseClassName:
                        parentWrapper = '%s_Wrapper' % k.name
            wrapperDef = 'class %s_Wrapper(%s, %s):\n' % \
                         (c.name, parentWrapper, parentClass)
            titleFound = False
            for attrName in c.orderedAttributes:
                if attrName == 'title':
                    titleFound = True
                attrValue = getattr(c.klass, attrName)
                if isinstance(attrValue, Type):
                    wrapperDef += self.generateWrapperProperty(attrName,
                                                               attrValue)
            # Generate properties for back references
            if self.referers.has_key(c.name):
                for refDescr, rel in self.referers[c.name]:
                    attrName = refDescr.appyType.back.attribute
                    wrapperDef += self.generateWrapperPropertyBack(attrName,rel)
            if not titleFound:
                # Implicitly, the title will be added by Archetypes. So I need
                # to define a property for it.
                wrapperDef += self.generateWrapperProperty('title', String())
            wrappers.append(wrapperDef)
        repls = self.repls.copy()
        repls['imports'] = '\n'.join(imports)
        repls['wrappers'] = '\n'.join(wrappers)
        repls['toolBody'] = Tool._appy_getBody()
        repls['flavourBody'] = Flavour._appy_getBody()
        repls['podTemplateBody'] = PodTemplate._appy_getBody()
        self.copyFile('appyWrappers.py', repls, destFolder='Extensions')

    def generateTool(self):
        '''Generates the Plone tool that corresponds to this application.'''
        # Generate the tool class in itself and related i18n messages
        t = self.toolName
        Msg = PoMessage
        repls = self.repls.copy()
        # Manage predefined fields
        Tool.flavours.klass = Flavour
        if self.customFlavourDescr:
            Tool.flavours.klass = self.customFlavourDescr.klass
        self.toolDescr = ToolClassDescriptor(Tool, self)
        repls['predefinedFields'] = self.toolDescr.schema
        repls['predefinedMethods'] = self.toolDescr.methods
        # Manage custom fields
        repls['fields'] = ''
        repls['methods'] = ''
        repls['wrapperClass'] = '%s_Wrapper' % self.toolDescr.name
        if self.customToolDescr:
            repls['fields'] = self.customToolDescr.schema
            repls['methods'] = self.customToolDescr.methods
            wrapperClass = '%s_Wrapper' % self.customToolDescr.name
            repls['wrapperClass'] = wrapperClass
        self.copyFile('ToolTemplate.py', repls, destName='%s.py'% self.toolName)
        repls = self.repls.copy()
        # Create i18n-related messages
        self.labels += [
            Msg(self.toolName, '', Msg.CONFIG % self.applicationName),
            Msg('%s_edit_descr' % self.toolName, '', ' ')]
        # Before generating the Flavour class, finalize it with query result
        # columns
        for classDescr in self.classes:
            if classDescr.isRoot():
                # We must be able to configure query results from the
                # flavour.
                Flavour._appy_addQueryResultColumns(classDescr, self.classes)
        # Generate the flavour class and related i18n messages
        self.labels += [ Msg(self.flavourName, '', Msg.FLAVOUR),
                         Msg('%s_edit_descr' % self.flavourName, '', ' ')]
        self.flavourDescr = FlavourClassDescriptor(Flavour, self)
        repls = self.repls.copy()
        repls['predefinedFields'] = self.flavourDescr.schema
        repls['predefinedMethods'] = self.flavourDescr.methods
        # Manage custom fields
        repls['fields'] = ''
        repls['methods'] = ''
        repls['wrapperClass'] = '%s_Wrapper' % self.flavourDescr.name
        if self.customFlavourDescr:
            repls['fields'] = self.customFlavourDescr.schema
            repls['methods'] = self.customFlavourDescr.methods
            wrapperClass = '%s_Wrapper' % self.customFlavourDescr.name
            repls['wrapperClass'] = wrapperClass
        repls['metaTypes'] = [c.name for c in self.classes]
        self.copyFile('FlavourTemplate.py', repls,
                      destName='%s.py'% self.flavourName)
        # Generate the PodTemplate class
        self.labels += [ Msg(self.podTemplateName, '', Msg.POD_TEMPLATE),
                         Msg('%s_edit_descr' % self.podTemplateName, '', ' ')]
        self.podTemplateDescr = PodTemplateClassDescriptor(PodTemplate,self)
        repls = self.repls.copy()
        repls['fields'] = self.podTemplateDescr.schema
        repls['methods'] = self.podTemplateDescr.methods
        repls['wrapperClass'] = '%s_Wrapper' % self.podTemplateDescr.name
        self.copyFile('PodTemplate.py', repls,
                        destName='%s.py' % self.podTemplateName)
        for imgName in PodTemplate.podFormat.validator:
            self.copyFile('%s.png' % imgName, {},
                            destFolder=self.skinsFolder)

    refFiles = ('createAppyObject.cpy', 'createAppyObject.cpy.metadata',
                'arrowUp.png', 'arrowDown.png', 'plus.png', 'appyConfig.gif',
                'nextPhase.png', 'nextState.png', 'done.png', 'current.png')
    prefixedRefFiles = ('AppyReference.pt',)
    def generateAppyReference(self):
        '''Generates what is needed to use Appy-specific references.'''
        # Some i18n messages
        Msg = PoMessage
        for refFile in self.prefixedRefFiles:
            self.copyFile(refFile, self.repls, destFolder=self.skinsFolder,
                          destName='%s%s' % (self.applicationName, refFile))
        for refFile in self.refFiles:
            self.copyFile(refFile, self.repls, destFolder=self.skinsFolder)

    def generateClass(self, klass, orderedAttributes, classType):
        '''Is called each time an Appy class is found in the application.'''
        # I need to generate the corresponding Archetype class and schema.
        # Generate appy fields
        if classType == 'tool':
            self.customToolDescr = CustomToolClassDescriptor(
                klass, orderedAttributes, self)
            return
        elif classType == 'flavour':
            self.customFlavourDescr = CustomFlavourClassDescriptor(
                klass, orderedAttributes, self)
            return
        classDescr = ArchetypesClassDescriptor(klass, orderedAttributes, self)
        self.classes.append(classDescr)
        if classDescr.isPod():
            Flavour._appy_addPodField(classDescr)
        # Determine base archetypes schema and class
        baseClass = 'BaseContent'
        baseSchema = 'BaseSchema'
        if classDescr.isFolder():
            baseClass = 'OrderedBaseFolder'
            baseSchema = 'OrderedBaseFolderSchema'
        parents = [baseClass, 'ClassMixin']
        imports = []
        implements = [baseClass]
        for baseClass in klass.__bases__:
            if self.determineAppyType(baseClass) == 'class':
                bcName = ArchetypesClassDescriptor.getClassName(baseClass)
                parents.remove('ClassMixin')
                parents.append(bcName)
                implements.append(bcName)
                imports.append('from %s import %s' % (bcName, bcName))
                baseSchema = '%s.schema' % bcName
                break
        parents = ','.join(parents)
        implements = '+'.join(['(getattr(%s,"__implements__",()),)' % i \
                               for i in implements])
        classDoc = klass.__doc__
        if not classDoc:
            classDoc = 'Class generated with appy.gen.'
        # If the class is abstract I will not register it
        register = "registerType(%s, '%s')" % (classDescr.name,
                                               self.applicationName)
        if classDescr.isAbstract():
            register = ''
        classDescr.addGenerateDocMethod() # For POD
        repls = self.repls.copy()
        repls.update({
          'imports': '\n'.join(imports), 'parents': parents,
          'className': klass.__name__, 'genClassName': classDescr.name,
          'classDoc': classDoc, 'applicationName': self.applicationName,
          'fields': classDescr.schema, 'methods': classDescr.methods,
          'implements': implements, 'baseSchema': baseSchema,
          'register': register, 'toolInstanceName': self.toolInstanceName})
        fileName = '%s.py' % classDescr.name
        # Remember i18n labels that will be generated in the i18n file
        poMsg = PoMessage(classDescr.name, '', klass.__name__)
        poMsg.produceNiceDefault()
        self.labels.append(poMsg)
        poMsgDescr = PoMessage('%s_edit_descr' % classDescr.name, '', ' ')
        self.labels.append(poMsgDescr)
        # Remember i18n labels for flavoured variants
        for i in range(2,10):
            poMsg = PoMessage('%s_%d' % (classDescr.name, i), '',klass.__name__)
            poMsg.produceNiceDefault()
            self.labels.append(poMsg)
            poMsgDescr = PoMessage('%s_%d_edit_descr' % (classDescr.name, i),
                                   '', ' ')
            self.labels.append(poMsgDescr)
        # Generate the resulting Archetypes class and schema.
        self.copyFile('ArchetypesTemplate.py', repls, destName=fileName)

    def generateWorkflow(self, workflow, orderedAttributes):
        # Create the workflow descriptor and remember it
        wfDescr = WorkflowDescriptor(workflow, orderedAttributes, self)
        self.workflows.append(wfDescr)
        # Identify Plone workflow name
        wfName = WorkflowDescriptor.getWorkflowName(workflow)
        # Add i18n messages for states and transitions
        for sName in wfDescr.getStateNames():
            poMsg = PoMessage('%s_%s' % (wfName, sName), '', sName)
            poMsg.produceNiceDefault()
            self.labels.append(poMsg)
        for tName, tLabel in wfDescr.getTransitionNames(withLabels=True):
            poMsg = PoMessage('%s_%s' % (wfName, tName), '', tLabel)
            poMsg.produceNiceDefault()
            self.labels.append(poMsg)
        # Generate the Archetypes workflow definition file
        repls = self.repls.copy()
        repls['workflowName'] = wfName
        repls['stateNames'] = ','.join(['"%s"' % sn for sn in \
                                        wfDescr.getStateNames()])
        repls['initialState'] = wfDescr.getInitialStateName()
        repls['transitionNames'] = ','.join(['"%s"' % tn for tn in \
                                            wfDescr.getTransitionNames()])
        repls['managedPermissions'] = ','.join(['"%s"' % tn for tn in \
                                               wfDescr.getManagedPermissions()])
        repls['stateInitialisation'] = wfDescr.getStateInitialisation()
        repls['transitionInitialisation']= wfDescr.getTransitionInitialisation()
        repls['scripts'] = wfDescr.getScripts()
        self.copyFile('workflow.py', repls, destName="%s.py" % wfName,
                      destFolder='Extensions')
        self.copyFile('workflow_scripts.py', repls,
                      destName="%s_scripts.py" % wfName,destFolder='Extensions')
# ------------------------------------------------------------------------------
