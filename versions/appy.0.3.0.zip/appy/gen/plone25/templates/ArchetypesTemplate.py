# -*- coding: utf-8 -*-
#
# GNU General Public License (GPL)
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
# 02110-1301, USA.
#

import types
from AccessControl import ClassSecurityInfo
from Products.Archetypes.atapi import *
from Extensions.appyWrappers import <!genClassName!>_Wrapper
from Extensions.appyMixins import ClassMixin
<!imports!>

schema = Schema((<!fields!>
),
)
fullSchema = <!baseSchema!>.copy() + schema.copy()

class <!genClassName!>(<!parents!>):
    '''<!classDoc!>'''
    security = ClassSecurityInfo()
    __implements__ = <!implements!>
    archetype_name = '<!genClassName!>'
    meta_type = '<!genClassName!>'
    portal_type = '<!genClassName!>'
    allowed_content_types = []
    filter_content_types = 0
    global_allow = 1
    immediate_view = '<!applicationName!>_appy_view'
    default_view = '<!applicationName!>_appy_view'
    suppl_views = ()
    typeDescription = '<!genClassName!>'
    typeDescMsgId = '<!genClassName!>_edit_descr'
    _at_rename_after_creation = True
    i18nDomain = '<!applicationName!>'
    schema = fullSchema
    wrapperClass = <!genClassName!>_Wrapper

<!commonMethods!>

    security.declarePublic('fieldIsUsed')
    def fieldIsUsed(self, fieldName):
        portalTypeName = self._appy_getPortalType(self.REQUEST)
        return self._appy_fieldIsUsed(portalTypeName, fieldName)

    security.declarePublic('getDefaultValueFor')
    def getDefaultValueFor(self, fieldName):
        portalTypeName = self._appy_getPortalType(self.REQUEST)
        return self._appy_getDefaultValueFor(portalTypeName,fieldName)
<!methods!>
<!register!>
