# -*- coding: utf-8 -*-
#
# GNU General Public License (GPL)
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
# 02110-1301, USA.
#

from Products.CMFCore.utils import getToolByName
from Products.CMFCore.WorkflowTool import addWorkflowFactory
from Products.DCWorkflow.DCWorkflow import DCWorkflowDefinition
from Products.ExternalMethod.ExternalMethod import ExternalMethod
from Products.<!applicationName!>.config import *

# Let's begin with a bunch of useful functions for initializing DC transitions.
def addTransitionScript(workflow, scriptName):
    '''Creates a transition-related script named p_scriptName for p_workflow.'''
    if not scriptName in workflow.scripts.objectIds():
        sn = scriptName
        workflow.scripts._setObject(sn, ExternalMethod(
            sn, sn, PROJECTNAME + '.<!workflowName!>_scripts', sn))

def setTransition(transitionName, transition, endStateName, scriptName):
    transition.setProperties(
        title=transitionName, new_state_id=endStateName, trigger_type=1,
        script_name="", after_script_name=scriptName,
        actbox_name='<!workflowName!>_%s' % transitionName, actbox_url="",
        props={'guard_expr': 'python:here.may("%s")' % transitionName})

# This is the method that initialises the workflow.
def setup<!workflowName!>(self, workflow):
    '''Defines the workflow <!workflowName!>.'''
    workflow.setProperties(title='<!workflowName!>')

    # Create states
    stateNames = [<!stateNames!>]
    for s in stateNames:
        try:
            workflow.states[s]
        except KeyError, k:
            # It does not exist, so we create it!
            workflow.states.addState(s)

    # Create transitions
    transitionNames = [<!transitionNames!>]
    for t in transitionNames:
        try:
            workflow.transitions[t]
        except KeyError, k:
            workflow.transitions.addTransition(t)

    # Create variables
    for v in ['review_history', 'comments', 'time', 'actor', 'action']:
        try:
            workflow.variables[v]
        except KeyError, k:
            workflow.variables.addVariable(v)

    # Create managed permissions
    managedPermissions = [<!managedPermissions!>]
    for mp in managedPermissions:
        try:
            workflow.addManagedPermission(mp)
        except ValueError, va:
            pass # Already a managed permission

    # Set initial state
    if not workflow.initial_state:
        workflow.states.setInitialState('<!initialState!>')

    # Initialise states
<!stateInitialisation!>
    # Initialise transitions
<!transitionInitialisation!>
    # Set the name of the state variable
    workflow.variables.setStateVar('review_state')

    # Initialise variables
    var = workflow.variables['review_history']
    var.setProperties(
        description='Provides access to workflow history', default_value='',
        default_expr='state_change/getHistory', for_catalog=0, for_status=0,
        update_always=0,
        props={'guard_permissions': 'Request review; Review portal content'})

    var = workflow.variables['comments']
    var.setProperties(
        description='Comments about the last transition', default_value='',
        default_expr='python:state_change.kwargs.get("comment", "")',
        for_catalog=0, for_status=1, update_always=1, props=None)

    var = workflow.variables['time']
    var.setProperties(
        description='Time of the last transition', default_value='',
        default_expr='state_change/getDateTime', for_catalog=0, for_status=1,
        update_always=1, props=None)

    var = workflow.variables['actor']
    var.setProperties(
        description='The ID of the user who performed the last transition',
        default_value='', default_expr='user/getId', for_catalog=0,
        for_status=1, update_always=1, props=None)

    var = workflow.variables['action']
    var.setProperties(
        description='The last transition', default_value='',
        default_expr='transition/getId|nothing', for_catalog=0, for_status=1,
        update_always=1, props=None)

def create<!workflowName!>(self, id):
    '''Creates the workflow for <!applicationName!>.'''
    ob = DCWorkflowDefinition(id)
    setup<!workflowName!>(self, ob)
    return ob

addWorkflowFactory(create<!workflowName!>, id='<!workflowName!>', title='<!workflowName!>')
