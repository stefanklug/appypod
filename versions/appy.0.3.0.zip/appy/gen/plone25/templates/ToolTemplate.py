# -*- coding: utf-8 -*-
#
# GNU General Public License (GPL)
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
# 02110-1301, USA.
#

import re, types
from AccessControl import ClassSecurityInfo
from Products.Archetypes.atapi import *
from Products.CMFCore.utils import UniqueObject, getToolByName
from Products.CMFPlone.PloneBatch import Batch
from Extensions.appyMixins import ToolMixin
from Extensions.appyWrappers import AbstractWrapper, <!wrapperClass!>
from appy.gen.utils import FieldDescr

predefinedSchema = Schema((<!predefinedFields!>
),
)
schema = Schema((<!fields!>
),
)
fullSchema = OrderedBaseFolderSchema.copy() + predefinedSchema.copy() + schema.copy()

class <!toolName!>(UniqueObject, OrderedBaseFolder, ToolMixin):
    '''Tool for <!applicationName!>.'''
    security = ClassSecurityInfo()
    __implements__ = (getattr(UniqueObject,'__implements__',()),) + (getattr(OrderedBaseFolder,'__implements__',()),)

    archetype_name = '<!toolName!>'
    meta_type = '<!toolName!>'
    portal_type = '<!toolName!>'
    allowed_content_types = ()
    filter_content_types = 0
    global_allow = 0
    #content_icon = '<!toolName!>.gif'
    immediate_view = '<!applicationName!>_appy_view'
    default_view = '<!applicationName!>_appy_view'
    suppl_views = ()
    typeDescription = "<!toolName!>"
    typeDescMsgId = '<!toolName!>_edit_descr'
    i18nDomain = '<!applicationName!>'
    wrapperClass = <!wrapperClass!>
    _at_rename_after_creation = True
    schema = fullSchema
    schema["id"].widget.visible = False
    schema["title"].widget.visible = False
    # When browsing into the tool, the 'configure' portlet should be dislayed.
    left_slots = ['here/portlet_prefs/macros/portlet']
    right_slots = []

<!commonMethods!>

    # Tool constructor have no id argument, the id is fixed.
    def __init__(self, id=None):
        OrderedBaseFolder.__init__(self, '<!toolInstanceName!>')
        self.setTitle('<!applicationName!>')

    security.declarePublic('getFlavour')
    def getFlavour(self, contextObjOrPortalType, appy=False):
        '''Gets the flavour that corresponds to p_contextObjOrPortalType.'''
        if isinstance(contextObjOrPortalType, basestring):
            portalTypeName = contextObjOrPortalType
        else:
            # It is the contextObj, not a portal type name
            portalTypeName = contextObjOrPortalType.portal_type
        res = None
        appyTool = self._appy_getWrapper(force=True)
        flavourNumber = None
        nameElems = portalTypeName.split('_')
        if len(nameElems) > 1:
            try:
                flavourNumber = int(nameElems[-1])
            except ValueError:
                pass
        if flavourNumber != None:
            for flavour in appyTool.flavours:
                if flavourNumber == flavour.number:
                    res = flavour
        elif portalTypeName == '<!applicationName!>Flavour':
            # Current object is the Flavour itself. In this cas we simply
            # return the wrapped contextObj. Here we are sure that
            # contextObjOrPortalType is an object, not a portal type.
            res = contextObjOrPortalType._appy_getWrapper(force=True)
        if not res and appyTool.flavours:
            res = appyTool.flavours[0]
        # If appy=False, return the Plone object and not the Appy wrapper
        # (this way, we avoid Zope security/access-related problems while
        # using this object in Zope Page Templates)
        if res and not appy:
            res = res.o
        return res

    security.declarePublic('getFlavours')
    def getFlavoursInfo(self):
        '''Returns information about flavours.'''
        res = []
        appyTool = self._appy_getWrapper(force=True)
        for flavour in appyTool.flavours:
            res.append({'title': flavour.title, 'number':flavour.number})
        return res

    security.declarePublic('getAppFolder')
    def getAppFolder(self):
        '''Returns the folder at the root of the Plone site that is dedicated
           to this application.'''
        portal = getToolByName(self, 'portal_url').getPortalObject()
        return getattr(portal, '<!applicationName!>')

    security.declarePublic('showPortlet')
    def showPortlet(self):
        return not self.portal_membership.isAnonymousUser()

    security.declarePublic('executeQuery')
    def executeQuery(self, queryName, flavourNumber):
        if queryName.find(',') != -1:
            # Several content types are specified
            portalTypes = queryName.split(',')
            if flavourNumber != 1:
                portalTypes = ['%s_%d' % (pt, flavourNumber) \
                               for pt in portalTypes]
        else:
            portalTypes = queryName
        params = {'portal_type': portalTypes, 'batch': True}
        res = self.portal_catalog.searchResults(**params)
        batchStart = self.REQUEST.get('b_start', 0)
        res = Batch(res, self.getNumberOfResultsPerPage(), int(batchStart),
                    orphan=0)
        return res

    security.declarePrivate('getResultColumnsNames')
    def getResultColumnsNames(self, queryName):
        contentTypes = queryName.strip(',').split(',')
        resSet = None # Temporary set for computing intersections.
        res = [] # Final, sorted result.
        flavour = None
        fieldNames = None
        for cType in contentTypes:
            # Get the flavour tied to those content types
            if not flavour:
                flavour = self.getFlavour(cType, appy=True)
            if flavour.number != 1:
                cType = cType.rsplit('_', 1)[0]
            fieldNames = getattr(flavour, 'resultColumnsFor%s' % cType)
            if not resSet:
                resSet = set(fieldNames)
            else:
                resSet = resSet.intersection(fieldNames)
        # By converting to set, we've lost order. Let's put things in the right
        # order.
        for fieldName in fieldNames:
            if fieldName in resSet:
                res.append(fieldName)
        return res

    security.declarePublic('getResultColumns')
    def getResultColumns(self, anObject, queryName):
        '''What columns must I show when displaying a list of root class
           instances? Result is a list of tuples containing the name of the
           column (=name of the field) and a FieldDescr instance.'''
        res = []
        for fieldName in self.getResultColumnsNames(queryName):
            if fieldName == 'workflowState':
                # We do not return a FieldDescr instance if the attributes is
                # not a *real* attribute but the workfow state.
                res.append(fieldName)
            else:
                # Create a FieldDescr instance
                appyType = anObject._appy_getType(fieldName)
                atField = anObject.schema.get(fieldName)
                fieldDescr = FieldDescr(atField, appyType, None)
                res.append(fieldDescr.get())
        return res

    xhtmlToText = re.compile('<.*?>', re.S)
    security.declarePublic('getReferenceLabel')
    def getReferenceLabel(self, brain, appyType):
        '''p_appyType is a Ref with link=True. I need to display, on an edit
           view, the referenced object p_brain in the listbox that will allow
           the user to choose which object(s) to link through the Ref.
           According to p_appyType, the label may only be the object title,
           or more if parameter appyType.shownInfo is used.'''
        res = brain.Title
        if 'title' in appyType['shownInfo']:
            # We may place it at another place
            res = ''
        appyObj = brain.getObject()._appy_getWrapper(force=True)
        for fieldName in appyType['shownInfo']:
            value = getattr(appyObj, fieldName)
            if isinstance(value, AbstractWrapper):
                value = value.title.decode('utf-8')
            elif isinstance(value, basestring):
                value = value.decode('utf-8')
                refAppyType = appyObj.o._appy_getType(fieldName)
                if refAppyType and (refAppyType['type'] == 'String') and \
                   (refAppyType['format'] == 2):
                    value = self.xhtmlToText.sub(' ', value)
            else:
                value = str(value)
            prefix = ''
            if res:
                prefix = ' | '
            res += prefix + value.encode('utf-8')
        maxWidth = self.getListBoxesMaximumWidth()
        if len(res) > maxWidth:
            res = res[:maxWidth-2] + '...'
        return res

    translationMapping = {'portal_path': ''}
    security.declarePublic('translateWithMapping')
    def translateWithMapping(self, label):
        '''Translates p_label in the application domain, with a default
           translation mapping.'''
        if not self.translationMapping['portal_path']:
            self.translationMapping['portal_path'] = \
                self.portal_url.getPortalPath()
        return self.utranslate(label, self.translationMapping,
                               domain='<!applicationName!>')

<!predefinedMethods!>
<!methods!>
registerType(<!toolName!>, '<!applicationName!>')
