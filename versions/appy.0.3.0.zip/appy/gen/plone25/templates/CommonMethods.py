    def at_post_create_script(self):
        '''Is called every time a new object is created.'''
        self._appy_onEdit(True)

    def at_post_edit_script(self):
        '''Is called every time an object is edited.'''
        self._appy_onEdit(False)

    def post_validate(self, REQUEST=None, errors=None):
        if not errors:
            # I only call this "inter-field-validation" if individual fields
            # validation succeeds. This way, the user must first correct
            # individual fields before being confronted to potential
            # inter-fields validation errors.
            self._appy_validateAllFields(REQUEST, errors)

    security.declarePublic('getAppyType')
    def getAppyType(self, fieldName):
        '''Returns the Appy type corresponding to p_fieldName.'''
        return self._appy_getType(fieldName)

    security.declarePublic('getAppyRefs')
    def getAppyRefs(self, fieldName):
        return self._appy_getRefs(fieldName, ploneObjects=True)

    security.declarePublic('getAppyBackRefs')
    def getAppyBackRefs(self):
        return self._appy_getBackRefs()

    security.declarePublic('getAppyRefIndex')
    def getAppyRefIndex(self, fieldName, obj):
        return self._appy_getRefIndex(fieldName, obj)

    security.declarePublic('getAppyRefPortalType')
    def getAppyRefPortalType(self, fieldName):
        return self._appy_getRefPortalType(fieldName)

    security.declarePublic('getAppyFields')
    def getAppyFields(self, isEdit, page):
        return self._appy_getFields(isEdit, page)

    security.declarePublic('getAppyPage')
    def getAppyPage(self, isEdit, phaseInfo, appyName=True):
        '''On which page am I? p_isEdit indicates if the current page is an
           edit or consult view. p_phaseInfo indicates the current phase.'''
        pageAttr = 'pageName'
        if isEdit:
            pageAttr = 'fieldset' # Archetypes page name
        default = phaseInfo['pages'][0]
        # Default page is the first page of the current phase
        res = self.REQUEST.get(pageAttr, default)
        if appyName and (res == 'default'):
            res = 'main'
        return res

    security.declarePublic('getAppyPages')
    def getAppyPages(self, phase):
        return self._appy_getPages(phase)

    security.declarePublic('getAppyPhases')
    def getAppyPhases(self, currentOnly=False, fieldset=None, forPlone=False):
        return self._appy_getPhases(currentOnly, fieldset, forPlone)

    security.declarePublic('getAppyStates')
    def getAppyStates(self, phase):
        return self._appy_getStates(phase)

    security.declarePublic('changeAppyRefOrder')
    def changeAppyRefOrder(self, fieldName, objectUid, newIndex, isDelta):
        return self._appy_changeRefOrder(fieldName, objectUid, newIndex,isDelta)

    security.declarePublic('getWorkflow')
    def getWorkflow(self, appy=True):
        '''Returns the Appy workflow instance that is relevant for this
           object. If p_appy is False, it returns the DC workflow.'''
        res = None
        if appy:
            # Get the workflow class first
            workflowClass = None
            if self.wrapperClass:
                appyClass = self.wrapperClass.__bases__[1]
                if hasattr(appyClass, 'workflow'):
                    workflowClass = appyClass.workflow
            if workflowClass:
                # Get the corresponding prototypical workflow instance
                from Products.<!applicationName!>.config import workflowInstances
                res = workflowInstances[workflowClass]
        else:
            dcWorkflows = self.portal_workflow.getWorkflowsFor(self)
            if dcWorkflows:
                res = dcWorkflows[0]
        return res

    security.declarePublic('getWorkflowLabel')
    def getWorkflowLabel(self, stateName=None):
        '''Gets the i18n label for the workflow current state. If no p_stateName
           is given, workflow label is given for the current state.'''
        res = ''
        wf = self.getWorkflow(appy=False)
        if wf:
            res = stateName
            if not res:
                res = self.portal_workflow.getInfoFor(self, 'review_state')
            appyWf = self.getWorkflow(appy=True)
            if appyWf:
                res = '%s_%s' % (wf.id, res)
        return res

    security.declarePublic('getComputedValue')
    def getComputedValue(self, appyType):
        '''Computes on p_self the value of the Computed field corresponding to
           p_appyType.'''
        return self._appy_getComputedValue(appyType)

    security.declarePublic('executeAppyAction')
    def executeAppyAction(self, actionName, reindex=True):
        '''Executes action with p_fieldName on this object.'''
        appyClass = self.wrapperClass.__bases__[1]
        res = getattr(appyClass, actionName)(self._appy_getWrapper(force=True))
        self.reindexObject()
        return res

    security.declarePublic('may')
    def may(self, transitionName):
        '''May the user execute transition named p_transitionName?'''
        # Get the Appy workflow instance
        workflow = self.getWorkflow()
        res = False
        if workflow:
            # Get the corresponding Appy transition
            transition = workflow._transitionsMapping[transitionName]
            user = self.portal_membership.getAuthenticatedMember()
            if isinstance(transition.condition, basestring):
                # It is a role. Transition may be triggered if the user has this
                # role.
                res = user.has_role(transition.condition, self)
            elif type(transition.condition) == types.FunctionType:
                obj = self._appy_getWrapper()
                res = transition.condition(workflow, obj)
            elif type(transition.condition) in (tuple, list):
                # It is a list of roles and or functions. Transition may be
                # triggered if user has at least one of those roles and if all
                # functions return True.
                hasRole = None
                for roleOrFunction in transition.condition:
                    if isinstance(roleOrFunction, basestring):
                        if hasRole == None:
                            hasRole = False
                        if user.has_role(roleOrFunction, self):
                            hasRole = True
                    elif type(roleOrFunction) == types.FunctionType:
                        obj = self._appy_getWrapper()
                        if not roleOrFunction(workflow, obj):
                            return False
                if hasRole != False:
                    res = True
        return res

    security.declarePublic('callAppySelect')
    def callAppySelect(self, selectMethod, brains):
        if selectMethod:
            obj = self._appy_getWrapper(force=True)
            allObjects = [b.getObject()._appy_getWrapper() \
                          for b in brains]
            filteredObjects = selectMethod(obj, allObjects)
            filteredUids = [o.o.UID() for o in filteredObjects]
            res = []
            for b in brains:
                if b.UID in filteredUids:
                    res.append(b)
        else:
            res = brains
        return res

    security.declarePublic('getCssClasses')
    def getCssClasses(self, appyType, asSlave=True):
        '''Gets the CSS classes (used for master/slave relationships) for this
           object, either as slave (p_asSlave=True) either as master.'''
        return self._appy_getCssClasses(appyType, asSlave)

    security.declarePublic('fieldValueSelected')
    def fieldValueSelected(self, fieldName, value, vocabValue):
        '''When displaying a selection box (ie a String with a validator being a
           list), must the _vocabValue appear as selected?'''
        return self._appy_fieldValueSelected(fieldName, value, vocabValue)

    security.declarePublic('checkboxChecked')
    def checkboxChecked(self, fieldName, value):
        '''When displaying a checkbox, must it be checked or not?'''
        return self._appy_checkboxChecked(fieldName, value)

    security.declarePublic('showField')
    def showField(self, fieldDescr, isEdit=False):
        '''Must I show field corresponding to p_fieldDescr?'''
        return self._appy_showField(fieldDescr, isEdit)

    security.declarePublic('getLabelPrefix')
    def getLabelPrefix(self, fieldName=None):
        '''For some i18n labels, wee need to determine a prefix, which may be
           linked to p_fieldName. Indeed, the prefix may be based on the name
           of the (super-)class where p_fieldName is defined.'''
        res = self.meta_type
        if fieldName:
            appyType = self._appy_getType(fieldName)
            res = '%s_%s' % (self._appy_getAtType(appyType['selfClass']),
                             fieldName)
        return res
