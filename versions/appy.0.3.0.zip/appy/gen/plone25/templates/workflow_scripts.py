# -*- coding: utf-8 -*-
#
# GNU General Public License (GPL)
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
# 02110-1301, USA.
#

# Workflow scripts for <!workflowName!>

def do(transitionName, stateChange):
    '''What must I do when a transition is triggered ?'''
    ploneObject = stateChange.object
    workflow = ploneObject.getWorkflow()
    transition = workflow._transitionsMapping[transitionName]
    if transition.action:
        obj = ploneObject._appy_getWrapper(force=True)
        if type(transition.action) in (tuple, list):
            # We need to execute a list of actions
            for act in transition.action: act(workflow, obj)
        else:
            # We execute a single action only.
            transition.action(workflow, obj)

<!scripts!>
