# -*- coding: utf-8 -*-
#
# GNU General Public License (GPL)
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
# 02110-1301, USA.
#

import sys, os.path
from StringIO import StringIO
from sets import Set
from zExceptions import NotFound, BadRequest
from App.Common import package_home
from Products.CMFCore.utils import getToolByName
from Products.CMFCore.utils import manage_addTool
from Products.ExternalMethod.ExternalMethod import ExternalMethod
from Products.Archetypes.Extensions.utils import installTypes
from Products.Archetypes.Extensions.utils import install_subskin
from Products.Archetypes.config import TOOL_NAME as ARCHETYPETOOLNAME
from Products.Archetypes.atapi import listTypes
from Products.<!applicationName!>.config import *
from Products.<!applicationName!>.config import product_globals as GLOBALS
import appy.gen
from appy.gen.utils import produceNiceMessage
from appy.gen.plone25.utils import updateRolesForPermission
<!imports!>

minimalistPlone = <!minimalistPlone!>
appClasses = <!appClasses!>
appClassNames = [<!appClassNames!>]
allClassNames = [<!allClassNames!>]
typeAliases = {'sharing': '', 'gethtml': '',
               '(Default)': '<!applicationName!>_appy_view',
               'edit': '<!applicationName!>_appy_edit',
               'index.html': '',
               'properties': '',
               'view': ''}

def findFile(klass, podTemplateName):
    '''Finds the file that corresponds to p_podTemplateName for p_klass.'''
    res = None
    exec 'moduleFile = %s.__file__' % klass.__module__
    folderName = os.path.dirname(moduleFile)
    fileName = os.path.join(folderName, '%s.odt' % podTemplateName)
    if os.path.isfile(fileName):
        res = fileName
    return res

def updatePodTemplates(appyTool):
    '''Creates or updates the POD templates in flavours according to pod
       declarations in the application classes.'''
    i = -1
    for klass in appClasses:
        i += 1
        if klass.__dict__.has_key('pod'):
            pod = getattr(klass, 'pod')
            if isinstance(pod, bool):
                podTemplates = [klass.__name__]
            else:
                podTemplates = pod
            for templateName in podTemplates:
                fileName = findFile(klass, templateName)
                if fileName:
                    # Create the corresponding PodTemplate in all flavours
                    for flavour in appyTool.flavours:
                        podId = '%s_%s' % (appClassNames[i], templateName)
                        podAttr = 'podTemplatesFor%s' % appClassNames[i]
                        allPodTemplates = getattr(flavour, podAttr)
                        if allPodTemplates:
                            if isinstance(allPodTemplates, list):
                                allIds = [p.id for p in allPodTemplates]
                            else:
                                allIds = [allPodTemplates.id]
                        else:
                            allIds = []
                        if podId not in allIds:
                            # Create a PodTemplate instance
                            f = file(fileName)
                            produceNiceMessage
                            flavour.create(podAttr, id=podId, podTemplate=f,
                                        title=produceNiceMessage(templateName))
                            f.close()

appyFolderType = 'AppyFolder'
def registerAppyFolderType(self):
    '''We need a specific content type for the folder that will hold all objects
       created from this application, in order to remove it from Plone
       navigation settings. We will create a new content type based on Large
       Plone Folder.'''
    if not hasattr(self.portal_types, appyFolderType):
        lpf = 'Large Plone Folder'
        largePloneFolder = getattr(self.portal_types, lpf)
        typeInfoName = 'ATContentTypes: ATBTreeFolder (ATBTreeFolder)'
        self.portal_types.manage_addTypeInformation(largePloneFolder.meta_type,
            id=appyFolderType, typeinfo_name=typeInfoName)
        appyFolder = getattr(self.portal_types, appyFolderType)
        appyFolder.title = 'Appy folder'
        #appyFolder.factory = largePloneFolder.factory
        #appyFolder.product = largePloneFolder.product
        # Copy actions and aliases
        appyFolder._actions = tuple(largePloneFolder._cloneActions())
        # Copy aliases from the base portal type
        appyFolder.setMethodAliases(largePloneFolder.getMethodAliases())
        # Prevent Appy folders to be visible in standard Plone navigation
        nv = self.portal_properties.navtree_properties
        metaTypesNotToList = list(nv.getProperty('metaTypesNotToList'))
        if appyFolderType not in metaTypesNotToList:
            metaTypesNotToList.append(appyFolderType)
        nv.manage_changeProperties(metaTypesNotToList=tuple(metaTypesNotToList))

actionsToHide = {
    'portal_actions': ('sitemap', 'accessibility', 'change_state', 'sendto'),
    'portal_membership': ('mystuff', 'preferences'),
    'portal_undo': ('undo',)
    }

def install(self, reinstall=False):
    '''Installation of product "<!applicationName!>"'''
    out = StringIO()
    print >> out, "Installation log of %s:" % PROJECTNAME

    # Hide some actions
    if minimalistPlone:
        for portalName, toHide in actionsToHide.iteritems():
            portal = getattr(self, portalName)
            portalActions = portal.listActions()
            for action in portalActions:
                if action.id in toHide:
                    action.visible = False

    # Create the application folder at the root of the Plone site if it does not
    # exist.
    registerAppyFolderType(self)
    if not hasattr(self.aq_base, "<!applicationName!>"):
        # Temporarily allow me to create Appy large plone folders
        getattr(self.portal_types, appyFolderType).global_allow = 1
        self.invokeFactory(appyFolderType, "<!applicationName!>",
                           title="<!applicationName!>")
        getattr(self.portal_types, appyFolderType).global_allow = 0
    appFolder = getattr(self, '<!applicationName!>')
    # All roles defined as creators should be able to create the
    # corresponding root content types in this folder.
    i = -1
    allCreators = set()
    for klass in appClasses:
        i += 1
        if klass.__dict__.has_key('root') and \
            klass.__dict__['root']:
            # It is a root class.
            creators = getattr(klass, 'creators', None)
            if not creators:
                creators = defaultAddRoles
            allCreators = allCreators.union(creators)
            className = appClassNames[i]
            updateRolesForPermission(ADD_CONTENT_PERMISSIONS[className],
                                     tuple(creators), appFolder)
    # Beyond content-type-specific "add" permissions, creators must also
    # have the main permission "Add portal content".
    updateRolesForPermission('Add portal content', tuple(allCreators),appFolder)

    DEPENDENCIES = []
    portal = getToolByName(self,'portal_url').getPortalObject()
    quickinstaller = portal.portal_quickinstaller
    for dependency in DEPENDENCIES:
        print >> out, "Installing dependency %s:" % dependency
        quickinstaller.installProduct(dependency)
        get_transaction().commit(1)

    classes = listTypes(PROJECTNAME)
    installTypes(self, out, classes, PROJECTNAME)
    install_subskin(self, out, GLOBALS)
    # Set appy view/edit pages for every created type
    for className in allClassNames + ['<!applicationName!>Tool']:
        # I did not put <!applicationName!>Tool in allClassNames because it
        # must not be registered in portal_factory
        if hasattr(self.portal_types, className):
            # className may correspond to an abstract class that have no
            # corresponding Plone content type
            typeInfo = getattr(self.portal_types, className)
            typeInfo.setMethodAliases(typeAliases)
            # Update edit and view actions
            typeActions = typeInfo.listActions()
            for action in typeActions:
                if action.id == 'view':
                    action.edit(action='string:${object_url}/<!applicationName!>_appy_view')
                elif action.id == 'edit':
                    action.edit(action='string:${object_url}/<!applicationName!>_appy_edit')

    # Enable portal_factory for given types
    factory_tool = getToolByName(self,'portal_factory')
    factory_types= allClassNames + factory_tool.getFactoryTypes().keys()
    factory_tool.manage_setPortalFactoryTypes(listOfTypeIds=factory_types)

    # Configure CatalogMultiplex:
    # explicit add classes (meta_types) be indexed in catalogs (white)
    # or removed from indexing in a catalog (black)
    atool = getToolByName(self, ARCHETYPETOOLNAME)
    catalogmap = {}
<!catalogMap!>
    for meta_type in catalogmap:
        submap = catalogmap[meta_type]
        current_catalogs = Set([c.id for c in atool.getCatalogsByType(meta_type)])
        if 'white' in submap:
            for catalog in submap['white']:
                if not getToolByName(self, catalog, False):
                    raise AttributeError, 'Catalog "%s" does not exist!' % catalog
                current_catalogs.update([catalog])
        if 'black' in submap:
            for catalog in submap['black']:
                if catalog in current_catalogs:
                    current_catalogs.remove(catalog)
        atool.setCatalogsByType(meta_type, list(current_catalogs))

    # Autoinstall tools
    for t in ['<!toolName!>']:
        try:
            portal.manage_addProduct[PROJECTNAME].manage_addTool(t)
        except BadRequest:
            # if an instance with the same name already exists this error will
            # be swallowed. Zope raises in an unelegant manner a 'Bad Request' error
            pass
        except:
            e = sys.exc_info()
            if e[0] != 'Bad Request':
                raise

    # Hide tools in the search form
    portalProperties = getToolByName(self, 'portal_properties', None)
    if portalProperties is not None:
        siteProperties = getattr(portalProperties, 'site_properties', None)
        if siteProperties is not None and siteProperties.hasProperty('types_not_searched'):
            for tool in ['<!toolName!>']:
                current = list(siteProperties.getProperty('types_not_searched'))
                if tool not in current:
                    current.append(tool)
                    siteProperties.manage_changeProperties(**{'types_not_searched' : current})

    # Remove workflow for tools
    portal_workflow = getToolByName(self, 'portal_workflow')
    for tool in ['<!toolName!>']:
        portal_workflow.setChainForPortalTypes([tool], '')

    # Add the flavours sub-folder and create the default flavour in it
    tool = portal['<!toolInstanceName!>']
    appyTool = tool._appy_getWrapper(force=True)
    if reinstall:
        tool.at_post_edit_script()
    else:
        tool.at_post_create_script()
    if not appyTool.flavours:
        appyTool.create('flavours', title='<!applicationName!>', number=1)
    updatePodTemplates(appyTool)
    # Uncatalog tool
    tool.unindexObject()

    # Hide tools in the navigation
    portalProperties = getToolByName(self, 'portal_properties', None)
    if portalProperties is not None:
        navtreeProperties = getattr(portalProperties, 'navtree_properties', None)
        if navtreeProperties is not None and navtreeProperties.hasProperty('idsNotToList'):
            for toolname in ['<!toolInstanceName!>']:
                current = list(navtreeProperties.getProperty('idsNotToList'))
                if toolname not in current:
                    current.append(toolname)
                    navtreeProperties.manage_changeProperties(**{'idsNotToList' : current})

    # Register tool as configlet
    portal_controlpanel = getToolByName(self,'portal_controlpanel')
    portal_controlpanel.unregisterConfiglet('<!toolName!>')
    portal_controlpanel.registerConfiglet(
        '<!toolName!>', #id of your Tool
        '<!applicationName!>', # Title of your Product
        'string:${portal_url}/<!toolInstanceName!>',
        'python:True', # a condition
        'Manage portal', # access permission
        'Products', # section to which the configlet should be added: (Plone, Products (default) or Member)
        1, # visibility
        '<!toolName!>ID',
        'site_icon.gif', # icon in control_panel
        '<!applicationName!>',
        None,
    )

    # Register roles used by workflows defined in this application if they are
    # not registered yet.
    data = list(self.__ac_roles__)
    for role in applicationRoles:
        if not role in data:
            data.append(role)
            # add to portal_role_manager
            # first try to fetch it. if its not there, we probaly have no PAS
            # or another way to deal with roles was configured.
            try:
                prm = self.acl_users.get('portal_role_manager', None)
                if prm is not None:
                    try:
                        prm.addRole(role, role,
                                    "Added by product '<!applicationName!>'")
                    except KeyError: # Role already exists
                        pass
            except AttributeError:
                pass
        # Create a specific group and grant him this role
        group = '%s_group' % role
        if not self.portal_groups.getGroupById(group):
            self.portal_groups.addGroup(group, title=group)
            self.portal_groups.setRolesForGroup(group, [role])
    self.__ac_roles__ = tuple(data)

    # Install custom workflows
    installWorkflows = ExternalMethod('temp', 'temp',
                                      PROJECTNAME+'.InstallWorkflows',
                                     'installWorkflows').__of__(self)
    print >> out,'Workflow Install:'
    res = installWorkflows(self, out)
    print >> out,res or 'no output'

    STYLESHEETS = [{'id': '<!applicationName!>.css', 'title': '<!applicationName!> CSS styles'}]
    try:
        portal_css = getToolByName(portal, 'portal_css')
        for stylesheet in STYLESHEETS:
            try:
                portal_css.unregisterResource(stylesheet['id'])
            except:
                pass
            defaults = {'id': '', 'media': 'all', 'enabled': True}
            defaults.update(stylesheet)
            portal_css.registerStylesheet(**defaults)
    except:
        # No portal_css registry
        pass
    JAVASCRIPTS = []
    try:
        portal_javascripts = getToolByName(portal, 'portal_javascripts')
        for javascript in JAVASCRIPTS:
            try:
                portal_javascripts.unregisterResource(javascript['id'])
            except:
                pass
            defaults = {'id': ''}
            defaults.update(javascript)
            portal_javascripts.registerScript(**defaults)
    except:
        # No portal_javascripts registry
        pass

    # Manage portlets
    portletName = 'here/<!portletName!>/macros/portlet' # This is the name of
    # the application-specific portlet
    leftPortlets = self.getProperty('left_slots')
    if leftPortlets == None:
        leftPortlets = []
    else:
        leftPortlets = list(leftPortlets)
    if portletName not in leftPortlets:
        leftPortlets.insert(0, portletName)
    # Remove some basic Plone portlets that make less sense when building web
    # applications.
    portletsToRemove = ["here/portlet_navigation/macros/portlet",
                        "here/portlet_recent/macros/portlet",
                        "here/portlet_related/macros/portlet"]
    if not minimalistPlone: portletsToRemove = []
    for p in portletsToRemove:
        if p in leftPortlets:
            leftPortlets.remove(p)
    print 'Changing portlets due to product install', leftPortlets
    self.manage_changeProperties(left_slots=tuple(leftPortlets))
    if minimalistPlone:
        self.manage_changeProperties(right_slots=())

    # Do not generate an action (tab) for each root folder
    if minimalistPlone:
        self.portal_properties.site_properties.manage_changeProperties(
            disable_folder_sections=True)

    # Do not allow an anonymous user to register himself as new user
    self.manage_permission('Add portal member', ('Manager',), acquire=0)

    # Call custom installer if any
    if hasattr(appyTool, 'install'): tool.executeAppyAction('install', reindex=False)

    # Replace Plone front-page with an application-specific page if requested
    if <!appFrontPage!>:
        self.manage_changeProperties(default_page='<!applicationName!>FrontPage')
    return out.getvalue()

def uninstall(self, reinstall=False):
    out = StringIO()

    # Unhide tools in the search form
    portalProperties = getToolByName(self, 'portal_properties', None)
    if portalProperties is not None:
        siteProperties = getattr(portalProperties, 'site_properties', None)
        if siteProperties is not None and siteProperties.hasProperty('types_not_searched'):
            for tool in ['<!toolName!>']:
                current = list(siteProperties.getProperty('types_not_searched'))
                if tool in current:
                    current.remove(tool)
                    siteProperties.manage_changeProperties(**{'types_not_searched' : current})

    # Unhide tools
    portalProperties = getToolByName(self, 'portal_properties', None)
    if portalProperties is not None:
        navtreeProperties = getattr(portalProperties, 'navtree_properties', None)
        if navtreeProperties is not None and navtreeProperties.hasProperty('idsNotToList'):
            for toolname in ['<!toolInstanceName!>']:
                current = list(navtreeProperties.getProperty('idsNotToList'))
                if toolname in current:
                    current.remove(toolname)
                    navtreeProperties.manage_changeProperties(**{'idsNotToList' : current})

    # Uninstall custom workflows
    uninstallWorkflows = ExternalMethod('temp', 'temp',
                                         PROJECTNAME+'.InstallWorkflows',
                                         'uninstallWorkflows').__of__(self)
    print >> out, 'Workflow Uninstall:'
    res = uninstallWorkflows(self, out)
    print >> out, res or 'no output'
    return out.getvalue()
