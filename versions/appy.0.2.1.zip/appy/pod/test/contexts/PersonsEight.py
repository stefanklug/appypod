from appy.pod.test.contexts import Person

persons = [Person('P1'), Person('P2'), Person('P3'), Person('P4'),
           Person('P5'), Person('P6'), Person('P7'), Person('P8')]
