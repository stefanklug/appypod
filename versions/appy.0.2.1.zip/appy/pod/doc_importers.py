# ------------------------------------------------------------------------------
# Appy is a framework for building applications in the Python language.
# Copyright (C) 2007 Gaetan Delannay

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301,USA.

# ------------------------------------------------------------------------------
import os, os.path
from appy.pod import PodError
from appy.pod.odf_parser import OdfEnvironment

# ------------------------------------------------------------------------------
BAD_FILE = "First arg to this function must be a file handler or the path to " \
           "a file on disk."
FILE_NOT_FOUND = "'%s' does not exist or is not a file."

# ------------------------------------------------------------------------------
class DocImporter:
    '''Base class used for importing external content into a pod template (an
       image, another pod template, another odt document...'''
    def __init__(self, fileNameOrHandler, tempFolder, ns):
        self.fileNameOrHandler = fileNameOrHandler
        self.res = u''
        self.ns = ns
        # Unpack some useful namespaces
        self.textNs = ns[OdfEnvironment.NS_TEXT]
        self.linkNs = ns[OdfEnvironment.NS_XLINK]
        self.importFolder = os.path.join(tempFolder, 'docImports')
        if isinstance(fileNameOrHandler, file):
            # I will need to dump file content in a temp file on disk.
            if not os.path.exists(self.importFolder):
                os.mkdir(self.importFolder)
            fileName = os.path.basename(fileNameOrHandler.name)
            self.importPath = os.path.join(self.importFolder, fileName)
            tempFile = file(self.importPath, 'w')
            tempFile.write(fileNameOrHandler.read())
            tempFile.close()
        else:
            # Check that the file exists
            if not isinstance(fileNameOrHandler, basestring):
                raise PodError(BAD_FILE)
            if not os.path.exists(fileNameOrHandler) or \
               (not os.path.isfile(fileNameOrHandler)):
                raise PodError(FILE_NOT_FOUND % fileNameOrHandler)
            self.importPath = fileNameOrHandler

class OdtImporter(DocImporter):
    '''This class allows to import the content of another ODT document into a
       pod template.'''
    def run(self):
        self.res += '<%s:section %s:name="PodImportSection">' \
                    '<%s:section-source %s:href="%s" ' \
                    '%s:filter-name="writer8"/></%s:section>' % (
                        self.textNs, self.textNs, self.textNs, self.linkNs,
                        self.importPath, self.textNs, self.textNs)
        return self.res
# ------------------------------------------------------------------------------
