expr1 = 'hello'
i1 = 45
f1 = 78.05
